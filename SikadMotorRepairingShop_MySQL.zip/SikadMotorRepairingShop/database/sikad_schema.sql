-- Optional: import this in phpMyAdmin (Import tab). The app also does this automatically on start-up.
CREATE DATABASE IF NOT EXISTS sikad_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sikad_db;

-- SIKAD MOTOR REPAIRING SHOP SERVICES - database tables (MySQL / MariaDB, InnoDB)
-- The application runs this file automatically on start-up (CREATE TABLE IF NOT EXISTS).
-- You can also import it manually in phpMyAdmin (see database/sikad_schema.sql).

CREATE TABLE IF NOT EXISTS customer (
  id            VARCHAR(20)  NOT NULL,
  first_name    VARCHAR(80)  NULL,
  last_name     VARCHAR(80)  NULL,
  address       VARCHAR(255) NULL,
  contact       VARCHAR(40)  NULL,
  email         VARCHAR(150) NULL,
  username      VARCHAR(80)  NULL,
  password_hash VARCHAR(255) NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS motorcycle (
  id          VARCHAR(20) NOT NULL,
  customer_id VARCHAR(20) NOT NULL,
  brand       VARCHAR(60) NULL,
  model       VARCHAR(80) NULL,
  plate       VARCHAR(30) NULL,
  engine_no   VARCHAR(60) NULL,
  color       VARCHAR(40) NULL,
  year_model  INT NOT NULL DEFAULT 0,
  mileage     INT NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  KEY idx_motorcycle_customer (customer_id),
  KEY idx_motorcycle_plate (plate),
  CONSTRAINT fk_motorcycle_customer FOREIGN KEY (customer_id) REFERENCES customer (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS service (
  id          VARCHAR(20)   NOT NULL,
  name        VARCHAR(120)  NULL,
  description VARCHAR(255)  NULL,
  duration    VARCHAR(40)   NULL,
  status      VARCHAR(20)   NULL,
  price       DECIMAL(12,2) NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS mechanic (
  id               VARCHAR(20)  NOT NULL,
  full_name        VARCHAR(120) NULL,
  contact          VARCHAR(40)  NULL,
  specialization   VARCHAR(60)  NULL,
  status           VARCHAR(20)  NULL,
  years_experience INT NOT NULL DEFAULT 0,
  password_hash    VARCHAR(255) NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS spare_part (
  id            VARCHAR(20)   NOT NULL,
  name          VARCHAR(120)  NULL,
  brand         VARCHAR(80)   NULL,
  category      VARCHAR(60)   NULL,
  supplier      VARCHAR(120)  NULL,
  unit_price    DECIMAL(12,2) NOT NULL DEFAULT 0,
  stock         INT NOT NULL DEFAULT 0,
  reorder_level INT NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS repair_job (
  id            VARCHAR(20)   NOT NULL,
  customer_id   VARCHAR(20)   NOT NULL,
  motorcycle_id VARCHAR(20)   NOT NULL,
  service_id    VARCHAR(20)   NOT NULL,
  mechanic_id   VARCHAR(20)   NULL,
  date_received VARCHAR(20)   NULL,
  expected_date VARCHAR(20)   NULL,
  complaint     TEXT          NULL,
  diagnosis     TEXT          NULL,
  recommended   TEXT          NULL,
  status        VARCHAR(40)   NULL,
  labor_cost    DECIMAL(12,2) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  KEY idx_job_customer (customer_id),
  KEY idx_job_motorcycle (motorcycle_id),
  KEY idx_job_service (service_id),
  KEY idx_job_mechanic (mechanic_id),
  CONSTRAINT fk_job_customer   FOREIGN KEY (customer_id)   REFERENCES customer (id),
  CONSTRAINT fk_job_motorcycle FOREIGN KEY (motorcycle_id) REFERENCES motorcycle (id),
  CONSTRAINT fk_job_service    FOREIGN KEY (service_id)    REFERENCES service (id),
  CONSTRAINT fk_job_mechanic   FOREIGN KEY (mechanic_id)   REFERENCES mechanic (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS part_usage (
  id            INT           NOT NULL AUTO_INCREMENT,
  repair_job_id VARCHAR(20)   NOT NULL,
  part_id       VARCHAR(20)   NULL,
  part_name     VARCHAR(120)  NULL,
  qty           INT           NOT NULL DEFAULT 0,
  unit_price    DECIMAL(12,2) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  KEY idx_usage_job (repair_job_id),
  KEY idx_usage_part (part_id),
  CONSTRAINT fk_usage_job  FOREIGN KEY (repair_job_id) REFERENCES repair_job (id) ON DELETE CASCADE,
  CONSTRAINT fk_usage_part FOREIGN KEY (part_id)       REFERENCES spare_part (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS invoice (
  id            VARCHAR(20)   NOT NULL,
  job_id        VARCHAR(20)   NOT NULL,
  invoice_date  VARCHAR(20)   NULL,
  other_charges DECIMAL(12,2) NOT NULL DEFAULT 0,
  discount      DECIMAL(12,2) NOT NULL DEFAULT 0,
  amount_paid   DECIMAL(12,2) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE KEY uq_invoice_job (job_id),
  CONSTRAINT fk_invoice_job FOREIGN KEY (job_id) REFERENCES repair_job (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS app_setting (
  setting_key   VARCHAR(60)  NOT NULL,
  setting_value VARCHAR(255) NULL,
  PRIMARY KEY (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
