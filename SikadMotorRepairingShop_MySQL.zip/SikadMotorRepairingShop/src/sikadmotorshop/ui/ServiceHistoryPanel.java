package sikadmotorshop.ui;

import java.util.*;
import sikadmotorshop.model.*;
import sikadmotorshop.util.*;

/** Read-only service history (finished repair jobs). Manager sees all; a customer sees only their own. */
public class ServiceHistoryPanel extends CrudPanel<RepairJob> {
    private final Customer scope;

    public ServiceHistoryPanel(Customer scope) {
        super(scope == null ? "Service History" : "My Service History");
        this.scope = scope;
        allowAdd = false; allowEdit = false; allowDelete = false;
        addAction("View Details", Theme.BLUE, () -> { RepairJob j = selected(); if (j != null) TextViewer.show(this, "Repair " + j.id, RepairJobPanel.details(j)); });
        buildButtons();
    }
    @Override protected String[] columns() { return new String[]{"Repair ID", "Date", "Customer", "Motorcycle", "Service Performed", "Mechanic", "Diagnosis", "Parts Used", "Total Cost", "Repair Status"}; }
    @Override protected int[] widths() { return new int[]{80, 90, 130, 190, 150, 120, 220, 220, 100, 130}; }
    @Override protected List<RepairJob> items() {
        List<RepairJob> l = new ArrayList<RepairJob>();
        for (RepairJob j : db.jobs) if (j.isDone() && (scope == null || j.customerId.equals(scope.id))) l.add(j);
        Collections.reverse(l);
        return l;
    }
    @Override protected Object[] row(RepairJob j) {
        return new Object[]{j.id, j.dateReceived, db.customerName(j.customerId), db.motoLabel(j.motorcycleId), db.serviceName(j.serviceId),
            db.mechanicName(j.mechanicId), j.diagnosis.isEmpty() ? "-" : j.diagnosis, j.partsSummary(), Fmt.money(j.totalCost()), j.status};
    }
}
