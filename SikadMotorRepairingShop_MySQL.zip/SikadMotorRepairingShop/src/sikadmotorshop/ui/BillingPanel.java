package sikadmotorshop.ui;

import java.util.*;
import sikadmotorshop.model.*;
import sikadmotorshop.util.*;

/** Billing. Manager edits charges and records payments; a customer (scope) can only view their own bills. */
public class BillingPanel extends CrudPanel<Invoice> {
    private final Customer scope;
    private final boolean readOnly;

    public BillingPanel(Customer scope) { this(scope, false); }

    /** Read-only mode is used by Manager to review billing history without changing charges or payments. */
    public BillingPanel(Customer scope, boolean readOnly) {
        super(scope == null ? "Billing" : "My Bills");
        this.scope = scope;
        this.readOnly = readOnly;
        allowAdd = false;
        addAction("View Bill", Theme.BLUE, this::viewBill);
        if (scope == null && !readOnly) addAction("Record Payment", Theme.GREEN, this::recordPayment);
        else { allowEdit = false; allowDelete = false; }
        buildButtons();
    }
    @Override protected String singular() { return "Invoice"; }
    @Override protected String editLabel() { return "Edit Charges"; }
    @Override protected String[] columns() {
        return new String[]{"Invoice ID", "Repair Job ID", "Customer", "Motorcycle", "Labor Cost", "Parts Cost", "Other Charges", "Discount", "Total Amount", "Amount Paid", "Balance", "Payment Status"};
    }
    @Override protected int[] widths() { return new int[]{90, 100, 130, 190, 90, 90, 100, 80, 110, 100, 100, 120}; }
    @Override protected List<Invoice> items() {
        List<Invoice> l = new ArrayList<Invoice>();
        for (Invoice i : db.invoices) { RepairJob j = db.job(i.jobId); if (j != null && (scope == null || j.customerId.equals(scope.id))) l.add(i); }
        Collections.reverse(l);
        return l;
    }
    @Override protected Object[] row(Invoice i) {
        RepairJob j = db.job(i.jobId);
        return new Object[]{i.id, i.jobId, db.customerName(j.customerId), db.motoLabel(j.motorcycleId), Fmt.money(j.laborCost), Fmt.money(j.partsCost()),
            Fmt.money(i.otherCharges), Fmt.money(i.discount), Fmt.money(i.total(j)), Fmt.money(i.amountPaid), Fmt.money(i.balance(j)), i.paymentStatus(j)};
    }
    @Override protected List<FieldSpec> fields(Invoice i) {
        return Arrays.asList(FieldSpec.readonly("Invoice ID"), FieldSpec.readonly("Repair Job ID"), FieldSpec.readonly("Labor + Parts"),
                FieldSpec.text("Other Charges"), FieldSpec.text("Discount"));
    }
    @Override protected String[] valuesOf(Invoice i) {
        RepairJob j = db.job(i.jobId);
        return new String[]{i.id, i.jobId, Fmt.money(j.laborCost + j.partsCost()), String.valueOf(i.otherCharges), String.valueOf(i.discount)};
    }
    @Override protected String save(Invoice i, String[] v) {
        RepairJob j = db.job(i.jobId);
        Double other = Validator.money(v[3]), disc = Validator.money(v[4]);
        if (other == null) return "Other charges must be a valid non-negative number.";
        if (disc == null) return "Discount must be a valid non-negative number.";
        double total = j.laborCost + j.partsCost() + other - disc;
        if (total < 0) return "Discount cannot be greater than labor + parts + other charges.";
        if (total < i.amountPaid - 0.004) return "The new total cannot be lower than the amount already paid (" + Fmt.money(i.amountPaid) + ").";
        i.otherCharges = other; i.discount = disc;
        return null;
    }
    @Override protected String deleteError(Invoice i) {
        return i.amountPaid > 0 ? "An invoice with recorded payments cannot be deleted." : null;
    }
    @Override protected void delete(Invoice i) { db.invoices.remove(i); }

    private void recordPayment() {
        Invoice i = selected(); if (i == null) return;
        RepairJob j = db.job(i.jobId);
        double bal = i.balance(j);
        if (bal <= 0.004) { info("This invoice is already fully paid."); return; }
        boolean ok = FormDialog.show(this, "Record Payment - " + i.id, Arrays.asList(FieldSpec.readonly("Balance"), FieldSpec.text("Payment Amount")),
                new String[]{Fmt.money(bal), String.format("%.2f", bal)}, v -> {
                    Double amt = Validator.money(v[1]);
                    if (amt == null || amt <= 0) return "Payment amount must be a number greater than 0.";
                    if (amt > bal + 0.004) return "Payment cannot be greater than the balance (" + Fmt.money(bal) + ").";
                    i.amountPaid += amt;
                    return null;
                });
        if (ok) { changed(); info("Payment recorded. Status: " + i.paymentStatus(j) + ", balance: " + Fmt.money(i.balance(j))); }
    }

    private void viewBill() {
        Invoice i = selected(); if (i == null) return;
        RepairJob j = db.job(i.jobId);
        StringBuilder sb = new StringBuilder();
        sb.append(Theme.BRAND).append("\nINVOICE ").append(i.id).append("   Date: ").append(i.date).append("\n");
        sb.append("------------------------------------------------\n");
        sb.append("Repair Job  : ").append(j.id).append('\n');
        sb.append("Customer    : ").append(db.customerName(j.customerId)).append('\n');
        sb.append("Motorcycle  : ").append(db.motoLabel(j.motorcycleId)).append('\n');
        sb.append("Service     : ").append(db.serviceName(j.serviceId)).append('\n');
        sb.append("Diagnosis   : ").append(j.diagnosis.isEmpty() ? "-" : j.diagnosis).append("\n\nParts:\n");
        if (j.parts.isEmpty()) sb.append("  (none)\n");
        for (PartUsage u : j.parts) sb.append(String.format("  %-22s x%-3d %12s%n", u.partName, u.qty, Fmt.money(u.total())));
        sb.append("------------------------------------------------\n");
        sb.append(String.format("Service / Labor Cost : %14s%n", Fmt.money(j.laborCost)));
        sb.append(String.format("Parts Cost           : %14s%n", Fmt.money(j.partsCost())));
        sb.append(String.format("Other Charges        : %14s%n", Fmt.money(i.otherCharges)));
        sb.append(String.format("Discount             : %14s%n", "-" + Fmt.money(i.discount)));
        sb.append(String.format("TOTAL AMOUNT         : %14s%n", Fmt.money(i.total(j))));
        sb.append(String.format("Amount Paid          : %14s%n", Fmt.money(i.amountPaid)));
        sb.append(String.format("BALANCE              : %14s%n", Fmt.money(i.balance(j))));
        sb.append("Payment Status       : ").append(i.paymentStatus(j)).append('\n');
        TextViewer.show(this, "Bill " + i.id, sb.toString());
    }
}
