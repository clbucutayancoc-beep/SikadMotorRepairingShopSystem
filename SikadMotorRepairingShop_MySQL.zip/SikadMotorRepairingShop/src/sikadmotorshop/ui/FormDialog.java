package sikadmotorshop.ui;

import java.awt.*;
import java.util.List;
import java.util.function.Function;
import javax.swing.*;

/** Generic modal form. The validator returns an error message (dialog stays open) or null (accepted). */
public final class FormDialog {
    private FormDialog() {}

    public static boolean show(Component parent, String title, List<FieldSpec> specs, String[] initial,
                               Function<String[], String> validator) {
        Window w = parent == null ? null : SwingUtilities.getWindowAncestor(parent);
        final JDialog d = new JDialog(w, title, Dialog.ModalityType.APPLICATION_MODAL);
        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createEmptyBorder(16, 20, 8, 20));
        final JComponent[] comps = new JComponent[specs.size()];
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(5, 4, 5, 4); gc.anchor = GridBagConstraints.NORTHWEST;
        for (int i = 0; i < specs.size(); i++) {
            FieldSpec s = specs.get(i);
            String init = initial != null && i < initial.length && initial[i] != null ? initial[i] : "";
            JComponent c;
            switch (s.type) {
                case FieldSpec.AREA: { JTextArea a = new JTextArea(init, 3, 26); a.setLineWrap(true); a.setWrapStyleWord(true);
                    a.setFont(Theme.BASE); c = a; break; }
                case FieldSpec.COMBO: { JComboBox<String> cb = new JComboBox<String>(s.options); cb.setFont(Theme.BASE);
                    if (!init.isEmpty()) cb.setSelectedItem(init); c = cb; break; }
                case FieldSpec.PASSWORD: { JPasswordField p = new JPasswordField(init, 26); c = p; break; }
                case FieldSpec.READONLY: { JTextField t = new JTextField(init, 26); t.setEditable(false);
                    t.setBackground(new Color(233, 236, 239)); c = t; break; }
                default: { JTextField t = new JTextField(init, 26); t.setFont(Theme.BASE); c = t; }
            }
            comps[i] = c;
            gc.gridx = 0; gc.gridy = i; gc.fill = GridBagConstraints.NONE; gc.weightx = 0;
            JLabel lb = new JLabel(s.label); lb.setFont(Theme.BOLD); form.add(lb, gc);
            gc.gridx = 1; gc.fill = GridBagConstraints.HORIZONTAL; gc.weightx = 1;
            form.add(s.type == FieldSpec.AREA ? new JScrollPane(c) : c, gc);
        }
        final boolean[] ok = {false};
        JButton save = Theme.primary("SAVE"), cancel = Theme.dark("CANCEL");
        save.addActionListener(e -> {
            String[] v = new String[comps.length];
            for (int i = 0; i < comps.length; i++) v[i] = read(comps[i]);
            String err = validator.apply(v);
            if (err != null) JOptionPane.showMessageDialog(d, err, "Validation Error", JOptionPane.WARNING_MESSAGE);
            else { ok[0] = true; d.dispose(); }
        });
        cancel.addActionListener(e -> d.dispose());
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 8));
        btns.add(save); btns.add(cancel);
        d.getContentPane().add(new JScrollPane(form, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER), BorderLayout.CENTER);
        d.getContentPane().add(btns, BorderLayout.SOUTH);
        d.getRootPane().setDefaultButton(save);
        d.pack();
        Dimension max = new Dimension(d.getWidth(), Math.min(d.getHeight(), 620));
        d.setSize(max);
        d.setLocationRelativeTo(parent);
        d.setVisible(true);
        return ok[0];
    }

    private static String read(JComponent c) {
        if (c instanceof JComboBox) { Object o = ((JComboBox<?>) c).getSelectedItem(); return o == null ? "" : o.toString(); }
        if (c instanceof JPasswordField) return new String(((JPasswordField) c).getPassword());
        if (c instanceof JTextArea) return ((JTextArea) c).getText().trim();
        return ((JTextField) c).getText().trim();
    }
}
