package sikadmotorshop.ui;

import java.time.LocalDate;
import java.util.*;
import sikadmotorshop.model.*;
import sikadmotorshop.util.*;

/**
 * Front-desk customer intake. A customer is recorded together with the motorcycle/unit
 * brought to the shop. Customer accounts/passwords are intentionally not collected.
 */
public class CustomersPanel extends CrudPanel<Customer> {
    public CustomersPanel() { super("Customer & Unit Intake"); buildButtons(); }
    @Override protected String singular() { return "Customer"; }
    @Override protected String[] columns() { return new String[]{"Customer ID", "First Name", "Last Name", "Address", "Contact Number", "Email", "Units"}; }
    @Override protected int[] widths() { return new int[]{90, 120, 120, 220, 120, 190, 70}; }
    @Override protected List<Customer> items() { return db.customers; }
    @Override protected Object[] row(Customer c) {
        int n = 0; for (Motorcycle m : db.motorcycles) if (m.customerId.equals(c.id)) n++;
        return new Object[]{c.id, c.firstName, c.lastName, c.address, c.contact, c.email, n};
    }

    @Override protected List<FieldSpec> fields(Customer c) {
        if (c == null && db.customers.size() >= 0) {
            return Arrays.asList(
                FieldSpec.readonly("Customer ID"),
                FieldSpec.text("First Name"), FieldSpec.text("Last Name"),
                FieldSpec.text("Address"), FieldSpec.text("Contact Number"), FieldSpec.text("Email"),
                FieldSpec.combo("Brand", Motorcycle.BRANDS), FieldSpec.text("Model"),
                FieldSpec.text("Plate Number"), FieldSpec.text("Color of the Unit"), FieldSpec.text("Year Model")
            );
        }
        // Editing keeps customer identity and also lets staff update the first registered unit.
        Motorcycle unit = firstUnit(c);
        return Arrays.asList(
            FieldSpec.readonly("Customer ID"),
            FieldSpec.text("First Name"), FieldSpec.text("Last Name"),
            FieldSpec.text("Address"), FieldSpec.text("Contact Number"), FieldSpec.text("Email"),
            FieldSpec.combo("Brand", Motorcycle.BRANDS), FieldSpec.text("Model"),
            FieldSpec.text("Plate Number"), FieldSpec.text("Color of the Unit"), FieldSpec.text("Year Model")
        );
    }

    private Motorcycle firstUnit(Customer c) {
        if (c == null) return null;
        for (Motorcycle m : db.motorcycles) if (m.customerId.equals(c.id)) return m;
        return null;
    }

    @Override protected String[] valuesOf(Customer c) {
        if (c == null) return new String[]{db.peekId("CUS"), "", "", "", "", "", "Honda", "", "", "", String.valueOf(LocalDate.now().getYear())};
        Motorcycle m = firstUnit(c);
        return new String[]{c.id, c.firstName, c.lastName, c.address, c.contact, c.email,
            m == null ? "Honda" : m.brand, m == null ? "" : m.model, m == null ? "" : m.plate,
            m == null ? "" : m.color, m == null ? String.valueOf(LocalDate.now().getYear()) : String.valueOf(m.year)};
    }

    @Override protected String save(Customer c, String[] v) {
        String err = Validator.required("First name", v[1]); if (err != null) return err;
        if ((err = Validator.required("Last name", v[2])) != null) return err;
        if ((err = Validator.required("Address", v[3])) != null) return err;
        if ((err = Validator.required("Contact number", v[4])) != null) return err;
        if ((err = Validator.required("Email", v[5])) != null) return err;
        if ((err = Validator.required("Model", v[7])) != null) return err;
        if ((err = Validator.required("Plate number", v[8])) != null) return err;
        if ((err = Validator.required("Color of the unit", v[9])) != null) return err;
        Integer year = Validator.nonNegInt(v[10]);
        if (year == null || year < 1950 || year > LocalDate.now().getYear() + 1)
            return "Year model must be a valid year (1950 - " + (LocalDate.now().getYear() + 1) + ").";

        String plate = v[8].trim().toUpperCase().replaceAll("\\s+", " ");
        for (Motorcycle o : db.motorcycles) if (!plate.equalsIgnoreCase(o.plate) || (c != null && o.customerId.equals(c.id) && o.plate.equalsIgnoreCase(plate))) {
            if (!o.plate.equalsIgnoreCase(plate)) continue;
            if (c == null || !o.customerId.equals(c.id)) return "Plate number " + plate + " is already registered.";
        }

        if (c == null) {
            c = new Customer(); c.id = db.nextId("CUS"); db.customers.add(c);
        }
        c.firstName = v[1]; c.lastName = v[2]; c.fullName = c.getFullName();
        c.address = v[3]; c.contact = v[4]; c.email = v[5];

        Motorcycle unit = firstUnit(c);
        if (unit == null) { unit = new Motorcycle(); unit.id = db.nextId("MOT"); unit.customerId = c.id; db.motorcycles.add(unit); }
        unit.brand = v[6]; unit.model = v[7]; unit.plate = plate; unit.color = v[9]; unit.year = year; unit.mileage = unit.mileage < 0 ? 0 : unit.mileage;
        return null;
    }

    @Override protected String deleteError(Customer c) {
        for (Motorcycle m : db.motorcycles) if (m.customerId.equals(c.id)) return "This customer still has registered units. Remove those records first.";
        for (Appointment a : db.appointments) if (a.customerId.equals(c.id)) return "This customer has appointments and cannot be deleted.";
        for (RepairJob j : db.jobs) if (j.customerId.equals(c.id)) return "This customer has repair jobs and cannot be deleted.";
        return null;
    }
    @Override protected void delete(Customer c) { db.customers.remove(c); }
}
