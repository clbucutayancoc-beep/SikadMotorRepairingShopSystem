package sikadmotorshop.ui;

/** Unified Manager/Staff operations window. Mechanics keep a separate dashboard. */
public class MainFrame extends ShellFrame {
    private final String role;

    public MainFrame() { this("Manager"); }

    public MainFrame(String role) {
        super("Sikad Manager / Staff Dashboard", role + " Console");
        this.role = role;

        // Shared dashboard and shared shop workflow for Manager and Staff.
        addPage("Dashboard", "dashboard", "Shop Dashboard", new ManagerDashboardPanel());
        addPage("Customers", "customers", "Customer & Unit Intake", new CustomersPanel());
        addPage("Motorcycles", "motorcycles", "Motorcycle Management", new MotorcyclePanel(null));
        addPage("Repair Jobs", "jobs", "Walk-in Repair Jobs", new RepairJobPanel((sikadmotorshop.model.Customer)null));
        addPage("Services", "services", "Service Management", new ServicesPanel());
        addPage("Mechanics", "mechanics", "Mechanics Management", new MechanicsPanel());

        // Stock editing remains restricted to the Manager account. Staff can only view/search stock.
        if ("Manager".equalsIgnoreCase(role)) {
            addPage("Spare Parts", "parts", "Spare Parts Inventory", new SparePartsPanel(true));
        } else {
            addPage("Spare Parts", "parts", "Spare Parts Inventory", new SparePartsPanel(false, true));
        }

        addPage("Billing", "billing", "Billing & Payments", new BillingPanel(null));
        addPage("Service History", "history", "Service History", new ServiceHistoryPanel(null));
        addPage("Reports", "reports", "Reports", new ReportsPanel());
        addLogout();
        showPage("dashboard");
    }

    public String getRole() { return role; }
}
