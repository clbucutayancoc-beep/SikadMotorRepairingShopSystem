package sikadmotorshop.ui;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;

/** Shared look and feel: charcoal sidebar, orange accent, light content panels. */
public final class Theme {
    private Theme() {}
    public static final String BRAND = "SIKAD MOTOR REPAIRING SHOP SERVICES";
    public static final Color SIDEBAR = new Color(33, 37, 41);
    public static final Color SIDEBAR_HOVER = new Color(52, 58, 64);
    public static final Color ACCENT = new Color(230, 81, 0);
    public static final Color BG = new Color(243, 244, 246);
    public static final Color TEXT = new Color(33, 37, 41);
    public static final Color MUTED = new Color(108, 117, 125);
    public static final Color GREEN = new Color(40, 167, 69);
    public static final Color RED = new Color(200, 35, 51);
    public static final Color BLUE = new Color(0, 105, 217);
    public static final Font BASE = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font BOLD = new Font("Segoe UI", Font.BOLD, 13);

    public static void install() {
        try { UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); } catch (Exception ignored) {}
        UIManager.put("OptionPane.messageFont", BASE);
        UIManager.put("OptionPane.buttonFont", BOLD);
    }

    public static JButton button(String text, Color bg) {
        JButton b = new JButton(text);
        b.setBackground(bg); b.setForeground(Color.WHITE); b.setFont(BOLD);
        b.setFocusPainted(false); b.setOpaque(true); b.setContentAreaFilled(true);
        b.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }
    public static JButton primary(String t) { return button(t, ACCENT); }
    public static JButton dark(String t) { return button(t, new Color(73, 80, 87)); }
    public static JButton danger(String t) { return button(t, RED); }

    public static JLabel title(String t) {
        JLabel l = new JLabel(t); l.setFont(new Font("Segoe UI", Font.BOLD, 22)); l.setForeground(TEXT); return l;
    }

    public static void styleTable(JTable t) {
        t.setFont(BASE); t.setRowHeight(28); t.setGridColor(new Color(225, 228, 232));
        t.setSelectionBackground(new Color(255, 224, 204)); t.setSelectionForeground(TEXT);
        t.setAutoCreateRowSorter(true);
        t.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        JTableHeader h = t.getTableHeader();
        h.setBackground(SIDEBAR); h.setForeground(Color.WHITE); h.setFont(BOLD); h.setReorderingAllowed(false);
        h.setPreferredSize(new Dimension(100, 32));
    }

    /** Status badge colors by keyword. */
    public static Color statusColor(String s) {
        String v = s.toLowerCase();
        if (v.equals("paid") || v.equals("completed") || v.equals("released") || v.equals("approved") || v.equals("available")
                || v.equals("in stock") || v.equals("active") || v.equals("ready for pickup")) return GREEN;
        if (v.equals("cancelled") || v.equals("unpaid") || v.equals("out of stock") || v.equals("inactive")) return RED;
        if (v.equals("low stock") || v.equals("partially paid") || v.equals("waiting for parts") || v.equals("busy")
                || v.equals("rescheduled") || v.equals("on leave") || v.equals("waiting for approval")) return new Color(214, 137, 16);
        if (v.equals("repair in progress") || v.equals("under inspection")) return BLUE;
        return new Color(108, 117, 125);
    }

    public static class StatusRenderer extends DefaultTableCellRenderer {
        @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
            JLabel l = (JLabel) super.getTableCellRendererComponent(t, v, sel, foc, r, c);
            l.setHorizontalAlignment(CENTER);
            if (v != null && !v.toString().isEmpty() && !v.toString().equals("-")) {
                l.setForeground(Color.WHITE); l.setBackground(statusColor(v.toString())); l.setFont(BOLD);
            }
            return l;
        }
    }

    /** Rounded white card showing a statistic. */
    public static class StatCard extends JPanel {
        private final JLabel value = new JLabel("0", SwingConstants.LEFT);
        public StatCard(String caption, Color accent) {
            setOpaque(false); setLayout(new BorderLayout(0, 6));
            setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
            JLabel cap = new JLabel(caption); cap.setFont(BOLD); cap.setForeground(MUTED);
            value.setFont(new Font("Segoe UI", Font.BOLD, 30)); value.setForeground(accent);
            add(cap, BorderLayout.NORTH); add(value, BorderLayout.CENTER);
        }
        public void set(String v) { value.setText(v); }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(Color.WHITE); g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 18, 18);
            g2.setColor(new Color(225, 228, 232)); g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 18, 18);
            g2.setColor(ACCENT); g2.fillRoundRect(0, 12, 5, getHeight() - 24, 5, 5);
            g2.dispose();
            super.paintComponent(g);
        }
    }
}
