package sikadmotorshop.ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import sikadmotorshop.data.DataStore;
import sikadmotorshop.model.Customer;
import sikadmotorshop.util.*;

/** Customer self-registration. */
public class CustomerRegistrationFrame extends JFrame {
    private final DataStore db = DataStore.get();
    private final LoginFrame loginFrame;
    private final JTextField id = new JTextField(24), firstName = new JTextField(24), lastName = new JTextField(24), address = new JTextField(24), contact = new JTextField(24),
        email = new JTextField(24), username = new JTextField(24);
    private final JPasswordField pass = new JPasswordField(24), confirm = new JPasswordField(24);
    private String registeredUser = null;

    public CustomerRegistrationFrame(LoginFrame loginFrame) {
        super("Customer Registration");
        this.loginFrame = loginFrame;
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(560, 640); setResizable(false); setLocationRelativeTo(null);
        getContentPane().setBackground(Color.WHITE);
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosed(WindowEvent e) {
                if (registeredUser != null) CustomerRegistrationFrame.this.loginFrame.prefill(registeredUser);
                CustomerRegistrationFrame.this.loginFrame.setVisible(true);
            }
        });
        JPanel head = new JPanel(new GridLayout(2, 1)); head.setBackground(Theme.SIDEBAR); head.setBorder(BorderFactory.createEmptyBorder(14, 24, 14, 24));
        JLabel a = new JLabel(Theme.BRAND); a.setForeground(Theme.ACCENT); a.setFont(Theme.BOLD);
        JLabel b = new JLabel("Customer Registration"); b.setForeground(Color.WHITE); b.setFont(new Font("Segoe UI", Font.BOLD, 20));
        head.add(a); head.add(b);
        add(head, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout()); form.setBackground(Color.WHITE); form.setBorder(BorderFactory.createEmptyBorder(16, 24, 8, 24));
        id.setEditable(false); id.setBackground(new Color(233, 236, 239));
        String[] labels = {"Customer ID", "First Name", "Last Name", "Address", "Contact Number", "Email", "Username", "Password", "Confirm Password"};
        JComponent[] f = {id, firstName, lastName, address, contact, email, username, pass, confirm};
        pass.setToolTipText("8-64 characters: uppercase, lowercase, number, and special character");
        confirm.setToolTipText("Re-enter the same strong password");
        GridBagConstraints gc = new GridBagConstraints(); gc.insets = new Insets(6, 4, 6, 4); gc.anchor = GridBagConstraints.WEST;
        for (int i = 0; i < f.length; i++) {
            gc.gridx = 0; gc.gridy = i; gc.fill = GridBagConstraints.NONE; JLabel l = new JLabel(labels[i]); l.setFont(Theme.BOLD); form.add(l, gc);
            gc.gridx = 1; gc.fill = GridBagConstraints.HORIZONTAL; gc.weightx = 1; form.add(f[i], gc);
        }
        add(form, BorderLayout.CENTER);
        JButton reg = Theme.primary("REGISTER"), clear = Theme.dark("CLEAR"), back = Theme.button("BACK TO LOGIN", Theme.BLUE);
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 12)); btns.setBackground(Color.WHITE);
        btns.add(reg); btns.add(clear); btns.add(back);
        add(btns, BorderLayout.SOUTH);
        reg.addActionListener(e -> register());
        clear.addActionListener(e -> clearForm());
        back.addActionListener(e -> dispose());
        clearForm();
    }

    private void clearForm() {
        id.setText(db.peekId("CUS"));
        for (JTextField t : new JTextField[]{firstName, lastName, address, contact, email, username, pass, confirm}) t.setText("");
    }

    private void register() {
        String err = Validator.customerError(firstName.getText().trim(), lastName.getText().trim(), address.getText().trim(), contact.getText().trim(), email.getText().trim(),
                username.getText().trim(), new String(pass.getPassword()), new String(confirm.getPassword()), true, null);
        if (err != null) { JOptionPane.showMessageDialog(this, err, "Registration Error", JOptionPane.WARNING_MESSAGE); return; }
        Customer c = new Customer();
        c.id = db.nextId("CUS"); c.firstName = firstName.getText().trim(); c.lastName = lastName.getText().trim(); c.fullName = c.getFullName(); c.address = address.getText().trim(); c.contact = contact.getText().trim();
        c.email = email.getText().trim(); c.username = username.getText().trim(); c.passwordHash = Security.hash(new String(pass.getPassword()));
        db.customers.add(c); db.save();
        registeredUser = c.username;
        JOptionPane.showMessageDialog(this, "Customer account successfully registered.\nYour Customer ID is " + c.id + ". You can now log in.");
        dispose();
    }
}
