package sikadmotorshop.ui;

/** Describes one input of a generic form dialog. */
public class FieldSpec {
    public static final int TEXT = 0, AREA = 1, COMBO = 2, PASSWORD = 3, READONLY = 4;
    public final String label;
    public final int type;
    public final String[] options;

    private FieldSpec(String label, int type, String[] options) { this.label = label; this.type = type; this.options = options; }
    public static FieldSpec text(String l) { return new FieldSpec(l, TEXT, null); }
    public static FieldSpec area(String l) { return new FieldSpec(l, AREA, null); }
    public static FieldSpec password(String l) { return new FieldSpec(l, PASSWORD, null); }
    public static FieldSpec readonly(String l) { return new FieldSpec(l, READONLY, null); }
    public static FieldSpec combo(String l, String... options) { return new FieldSpec(l, COMBO, options); }
}
