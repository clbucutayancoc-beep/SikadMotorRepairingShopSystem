package sikadmotorshop.ui;

import java.util.*;
import sikadmotorshop.model.*;
import sikadmotorshop.util.*;

/** Manager: mechanic management. */
public class MechanicsPanel extends CrudPanel<Mechanic> {
    public MechanicsPanel() { super("Mechanics Management"); buildButtons(); }
    @Override protected String singular() { return "Mechanic"; }
    @Override public void refresh() { db.syncMechanics(); super.refresh(); }
    @Override protected String[] columns() { return new String[]{"Mechanic ID", "Full Name", "Contact Number", "Specialization", "Years of Experience", "Mechanic Status"}; }
    @Override protected int[] widths() { return new int[]{100, 200, 130, 160, 130, 120}; }
    @Override protected List<Mechanic> items() { return db.mechanics; }
    @Override protected Object[] row(Mechanic m) { return new Object[]{m.id, m.fullName, m.contact, m.specialization, m.yearsExperience, m.status}; }
    @Override protected List<FieldSpec> fields(Mechanic m) {
        return Arrays.asList(FieldSpec.readonly("Mechanic ID / Login Username"), FieldSpec.text("Full Name"), FieldSpec.text("Contact Number"),
                FieldSpec.combo("Specialization", Mechanic.SPECIALIZATIONS), FieldSpec.text("Years of Experience"), FieldSpec.combo("Status", Mechanic.STATUSES));
    }
    @Override protected String[] valuesOf(Mechanic m) {
        if (m == null) return new String[]{db.peekId("MEC"), "", "", Mechanic.SPECIALIZATIONS[0], "0", "Available"};
        return new String[]{m.id, m.fullName, m.contact, m.specialization, String.valueOf(m.yearsExperience), m.status};
    }
    @Override protected String save(Mechanic m, String[] v) {
        String e;
        if ((e = Validator.required("Full name", v[1])) != null) return e;
        if ((e = Validator.required("Contact number", v[2])) != null) return e;
        if (!Validator.phone(v[2])) return "Contact number is invalid. Use 09XXXXXXXXX or +639XXXXXXXXX.";
        Integer yrs = Validator.nonNegInt(v[4]);
        if (yrs == null || yrs > 60) return "Years of experience must be a whole number between 0 and 60.";
        if (m == null) { m = new Mechanic(); m.id = db.nextId("MEC"); db.mechanics.add(m); }
        m.fullName = v[1]; m.contact = v[2]; m.specialization = v[3]; m.yearsExperience = yrs; m.status = v[5];
        if (m.passwordHash == null) m.passwordHash = Security.hash("Mechanic@2026!");
        return null;
    }
    @Override protected String deleteError(Mechanic m) {
        for (RepairJob j : db.jobs) if (m.id.equals(j.mechanicId)) return "This mechanic is assigned to repair jobs. Set the status to Inactive instead.";
        for (Appointment a : db.appointments) if (m.id.equals(a.mechanicId)) return "This mechanic is assigned to appointments. Set the status to Inactive instead.";
        return null;
    }
    @Override protected void delete(Mechanic m) { db.mechanics.remove(m); }
    @Override protected void changed() { db.syncMechanics(); super.changed(); }
}
