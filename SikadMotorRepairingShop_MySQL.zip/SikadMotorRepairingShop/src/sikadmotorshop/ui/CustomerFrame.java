package sikadmotorshop.ui;

import sikadmotorshop.model.Customer;

/** Customer window ("Sikad Customer Dashboard"). Every panel is scoped to the logged-in customer. */
public class CustomerFrame extends ShellFrame {
    public CustomerFrame(Customer me) {
        super("Sikad Customer Dashboard", "Welcome, " + me.getFullName());
        final AppointmentPanel appts = new AppointmentPanel(me);
        addPage("Dashboard", "dashboard", "Dashboard", new CustomerDashboardPanel(me));
        addPage("My Profile", "profile", "My Profile", new ProfilePanel(me));
        addPage("My Motorcycles", "motorcycles", "Motorcycle Management", new MotorcyclePanel(me));
        addAction("Book Appointment", () -> { showPage("appointments"); appts.addRecord(); });
        addPage("My Appointments", "appointments", "Appointment Management", appts);
        addPage("My Repair Jobs", "jobs", "Repair Job Status", new RepairJobPanel(me));
        addPage("Service History", "history", "Service History", new ServiceHistoryPanel(me));
        addPage("My Bills", "billing", "Billing", new BillingPanel(me));
        addLogout();
        showPage("dashboard");
    }
}
