package sikadmotorshop.ui;

import java.util.*;
import javax.swing.*;
import sikadmotorshop.model.*;
import sikadmotorshop.util.*;

/** Manager: motorcycle spare parts inventory with automatic stock status. */
public class SparePartsPanel extends CrudPanel<SparePart> {
    private final JToggleButton lowOnly = new JToggleButton("View Low Stock Only");
    private final boolean viewOnly;

    public SparePartsPanel() { this(false, false); }

    /** Manager mode: view inventory and update stock, but cannot add/edit/delete parts. */
    public SparePartsPanel(boolean restockOnly) { this(restockOnly, false); }

    /** Staff view-only mode: inventory can be checked, but stock cannot be changed. */
    public SparePartsPanel(boolean restockOnly, boolean viewOnly) {
        super("Spare Parts Inventory");
        this.viewOnly = viewOnly;
        if (restockOnly || viewOnly) { allowAdd = false; allowEdit = false; allowDelete = false; }
        if (!viewOnly) addAction("Update Stock", Theme.BLUE, this::updateStock);
        lowOnly.setFont(Theme.BOLD); lowOnly.addActionListener(e -> refresh());
        actions.add(lowOnly);
        buildButtons();
    }
    @Override protected String singular() { return "Spare Part"; }
    @Override protected String[] columns() { return new String[]{"Part ID", "Part Name", "Brand", "Category", "Unit Price", "Stock", "Reorder Level", "Supplier", "Stock Status"}; }
    @Override protected int[] widths() { return new int[]{80, 170, 110, 120, 100, 60, 100, 160, 110}; }
    @Override protected List<SparePart> items() { return lowOnly.isSelected() ? db.lowStockParts() : db.parts; }
    @Override protected Object[] row(SparePart p) {
        return new Object[]{p.id, p.name, p.brand, p.category, Fmt.money(p.unitPrice), p.stock, p.reorderLevel, p.supplier, p.status()};
    }
    @Override protected List<FieldSpec> fields(SparePart p) {
        return Arrays.asList(FieldSpec.readonly("Part ID"), FieldSpec.text("Part Name"), FieldSpec.text("Brand"),
                FieldSpec.combo("Category", SparePart.CATEGORIES), FieldSpec.text("Unit Price"), FieldSpec.text("Stock Quantity"),
                FieldSpec.text("Reorder Level"), FieldSpec.text("Supplier"));
    }
    @Override protected String[] valuesOf(SparePart p) {
        if (p == null) return new String[]{db.peekId("PRT"), "", "", SparePart.CATEGORIES[0], "", "0", "5", ""};
        return new String[]{p.id, p.name, p.brand, p.category, String.valueOf(p.unitPrice), String.valueOf(p.stock), String.valueOf(p.reorderLevel), p.supplier};
    }
    @Override protected String save(SparePart p, String[] v) {
        String e;
        if ((e = Validator.required("Part name", v[1])) != null) return e;
        if ((e = Validator.required("Brand", v[2])) != null) return e;
        if ((e = Validator.required("Supplier", v[7])) != null) return e;
        Double price = Validator.money(v[4]);
        if (price == null) return "Unit price must be a valid non-negative number.";
        Integer stock = Validator.nonNegInt(v[5]);
        if (stock == null) return "Stock quantity must be a whole number that is not negative.";
        Integer reorder = Validator.nonNegInt(v[6]);
        if (reorder == null) return "Reorder level must be a whole number that is not negative.";
        for (SparePart o : db.parts) if (o != p && o.name.equalsIgnoreCase(v[1]) && o.brand.equalsIgnoreCase(v[2]))
            return "This part (same name and brand) already exists. Use Update Stock instead.";
        if (p == null) { p = new SparePart(); p.id = db.nextId("PRT"); db.parts.add(p); }
        p.name = v[1]; p.brand = v[2]; p.category = v[3]; p.unitPrice = price; p.stock = stock; p.reorderLevel = reorder; p.supplier = v[7];
        return null;
    }
    @Override protected String deleteError(SparePart p) {
        for (RepairJob j : db.jobs) for (PartUsage u : j.parts) if (u.partId.equals(p.id)) return "This part was used in a repair job and cannot be deleted.";
        return null;
    }
    @Override protected void delete(SparePart p) { db.parts.remove(p); }

    private void updateStock() {
        SparePart p = selected(); if (p == null) return;
        boolean ok = FormDialog.show(this, "Update Stock - " + p.name,
                Arrays.asList(FieldSpec.readonly("Current Stock"), FieldSpec.combo("Action", "Add Stock", "Deduct Stock"), FieldSpec.text("Quantity")),
                new String[]{String.valueOf(p.stock), "Add Stock", "1"}, v -> {
                    Integer q = Validator.nonNegInt(v[2]);
                    if (q == null || q == 0) return "Quantity must be a whole number greater than 0.";
                    if (v[1].equals("Deduct Stock") && q > p.stock) return "Cannot deduct more than the current stock (" + p.stock + ").";
                    p.stock += v[1].equals("Add Stock") ? q : -q;
                    return null;
                });
        if (ok) { changed(); info("Stock updated. New stock: " + p.stock + " (" + p.status() + ")"); }
    }
}
