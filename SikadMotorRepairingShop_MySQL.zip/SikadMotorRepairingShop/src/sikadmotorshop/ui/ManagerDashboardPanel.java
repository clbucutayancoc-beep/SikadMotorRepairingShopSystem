package sikadmotorshop.ui;

import java.awt.*;
import javax.swing.*;
import sikadmotorshop.data.DataStore;
import sikadmotorshop.model.Motorcycle;
import sikadmotorshop.model.SparePart;
import sikadmotorshop.util.Fmt;

/** Shared Manager / Staff dashboard for daily shop operations and monitoring. */
public class ManagerDashboardPanel extends JPanel implements Refreshable {
    private final DataStore db = DataStore.get();
    private final Theme.StatCard units = new Theme.StatCard("REGISTERED UNITS", Theme.BLUE);
    private final Theme.StatCard parts = new Theme.StatCard("INVENTORY ITEMS", Theme.TEXT);
    private final Theme.StatCard low = new Theme.StatCard("LOW STOCK", Theme.RED);
    private final Theme.StatCard out = new Theme.StatCard("OUT OF STOCK", Theme.RED);
    private final Theme.StatCard stockValue = new Theme.StatCard("STOCK VALUE", Theme.GREEN);
    private final Theme.StatCard completed = new Theme.StatCard("COMPLETED REPAIRS", Theme.BLUE);
    private final Theme.StatCard billed = new Theme.StatCard("TOTAL BILLED", Theme.TEXT);
    private final Theme.StatCard collected = new Theme.StatCard("COLLECTED", Theme.GREEN);
    private final Theme.StatCard outstanding = new Theme.StatCard("OUTSTANDING", Theme.RED);

    public ManagerDashboardPanel() {
        super(new BorderLayout(0, 18));
        setBackground(Theme.BG); setBorder(BorderFactory.createEmptyBorder(24, 28, 24, 28));
        JPanel head = new JPanel(new GridLayout(2, 1)); head.setOpaque(false);
        JLabel t = new JLabel("Manager / Staff Dashboard"); t.setFont(new Font("Segoe UI", Font.BOLD, 24)); t.setForeground(Theme.TEXT);
        JLabel s = new JLabel("Walk-in customers, repair jobs, inventory, billing and shop performance"); s.setForeground(Theme.MUTED);
        head.add(t); head.add(s); add(head, BorderLayout.NORTH);

        JPanel grid = new JPanel(new GridLayout(2, 5, 14, 14)); grid.setOpaque(false);
        for (Theme.StatCard c : new Theme.StatCard[]{units, parts, low, out, stockValue, completed, billed, collected, outstanding}) grid.add(c);
        grid.add(new JLabel());
        add(grid, BorderLayout.CENTER);

        JPanel note = new JPanel(new BorderLayout(0, 8)); note.setBackground(Color.WHITE);
        note.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(225,228,232)), BorderFactory.createEmptyBorder(16,18,16,18)));
        JLabel h = new JLabel("Shared shop overview"); h.setFont(new Font("Segoe UI", Font.BOLD, 16)); h.setForeground(Theme.TEXT);
        JLabel n = new JLabel("<html>Manager and Staff use the same dashboard for customer/unit intake, repair jobs, services, mechanics, billing, service history and reports.<br><b>Inventory permission:</b> Manager can restock/deduct stock; Staff can view and search stock only. Mechanics retain a separate dashboard.</html>");
        n.setForeground(Theme.MUTED); note.add(h, BorderLayout.NORTH); note.add(n, BorderLayout.CENTER);
        add(note, BorderLayout.SOUTH); refresh();
    }
    public void refresh() {
        int lowCount = 0, outCount = 0; double value = 0;
        for (SparePart p : db.parts) { value += p.unitPrice * p.stock; if (p.stock <= 0) outCount++; else if (p.stock <= p.reorderLevel) lowCount++; }
        double totalBilled = 0, totalCollected = 0; int completedJobs = 0;
        for (sikadmotorshop.model.RepairJob j : db.jobs) if (j.isDone()) completedJobs++;
        for (sikadmotorshop.model.Invoice i : db.invoices) { sikadmotorshop.model.RepairJob j = db.job(i.jobId); if (j != null) { totalBilled += i.total(j); totalCollected += i.amountPaid; } }
        units.set(String.valueOf(db.motorcycles.size())); parts.set(String.valueOf(db.parts.size())); low.set(String.valueOf(lowCount)); out.set(String.valueOf(outCount)); stockValue.set(Fmt.money(value));
        completed.set(String.valueOf(completedJobs)); billed.set(Fmt.money(totalBilled)); collected.set(Fmt.money(totalCollected)); outstanding.set(Fmt.money(Math.max(0, totalBilled - totalCollected)));
    }
}
