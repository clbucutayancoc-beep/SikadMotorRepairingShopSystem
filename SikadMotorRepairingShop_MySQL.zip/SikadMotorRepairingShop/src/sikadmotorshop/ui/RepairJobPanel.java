package sikadmotorshop.ui;

import java.awt.*;
import java.awt.event.*;
import java.time.LocalDate;
import java.util.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import sikadmotorshop.model.*;
import sikadmotorshop.util.*;

/** Repair jobs. Manager creates/diagnoses/updates; a customer (scope) can only view their own. */
public class RepairJobPanel extends CrudPanel<RepairJob> {
    private final Customer scope;
    private final Mechanic mechanicScope;

    public RepairJobPanel(Customer scope) {
        super(scope == null ? "Walk-in Repair Job Management" : "My Repair Jobs");
        this.scope = scope; this.mechanicScope = null;
        addAction("View Details", Theme.BLUE, this::viewDetails);
        if (scope == null) {
            addAction("Update Status", Theme.GREEN, this::updateStatus);
            addAction("Manage Parts", new Color(73, 80, 87), this::manageParts);
            addAction("Generate Bill", Theme.ACCENT, this::generateBill);
        } else { allowAdd = false; allowEdit = false; allowDelete = false; }
        buildButtons();
    }
    /** Mechanic-scoped workstation constructor. */
    public RepairJobPanel(Mechanic mechanic) {
        super("Assigned Repair Jobs");
        this.scope = null; this.mechanicScope = mechanic;
        allowAdd = false; allowDelete = false; allowEdit = true;
        addAction("View Details", Theme.BLUE, this::viewDetails);
        addAction("Update Status", Theme.GREEN, this::updateStatus);
        addAction("Manage Parts", new Color(73,80,87), this::manageParts);
        buildButtons();
    }

    @Override protected String singular() { return "Repair Job"; }
    @Override protected String addLabel() { return "New Repair Job"; }
    @Override protected String editLabel() { return "Edit / Diagnose"; }
    @Override protected String[] columns() {
        return new String[]{"Job ID", "Customer", "Motorcycle", "Service", "Mechanic", "Received", "Expected", "Labor Cost", "Parts Cost", "Total Cost", "Repair Status"};
    }
    @Override protected int[] widths() { return new int[]{80, 130, 190, 140, 120, 90, 90, 90, 90, 100, 150}; }
    @Override public void refresh() { db.syncMechanics(); super.refresh(); }
    @Override protected List<RepairJob> items() {
        List<RepairJob> l = new ArrayList<RepairJob>();
        for (RepairJob j : db.jobs) if ((mechanicScope != null && mechanicScope.id.equals(j.mechanicId)) || (mechanicScope == null && (scope == null || j.customerId.equals(scope.id)))) l.add(j);
        Collections.reverse(l);
        return l;
    }
    @Override protected Object[] row(RepairJob j) {
        return new Object[]{j.id, db.customerName(j.customerId), db.motoLabel(j.motorcycleId), db.serviceName(j.serviceId), db.mechanicName(j.mechanicId),
            j.dateReceived, j.expectedDate, Fmt.money(j.laborCost), Fmt.money(j.partsCost()), Fmt.money(j.totalCost()), j.status};
    }

    // ---- form ----
    private String[] mechanicOptions(RepairJob cur) {
        List<String> l = new ArrayList<String>(); l.add("(Unassigned)");
        for (Mechanic m : db.mechanics)
            if (m.status.equals("Available") || m.status.equals("Busy") || (cur != null && m.id.equals(cur.mechanicId)))
                l.add(m.id + " - " + m.fullName);
        return l.toArray(new String[0]);
    }
    @Override protected List<FieldSpec> fields(RepairJob j) {
        String[] motos = new String[db.motorcycles.size()];
        for (int i = 0; i < motos.length; i++) { Motorcycle m = db.motorcycles.get(i); motos[i] = m.id + " - " + m.label() + " - " + db.customerName(m.customerId); }
        if (j == null && motos.length == 0) { warn("No motorcycles are registered yet."); return null; }
        String[] svc = new String[db.services.size()];
        for (int i = 0; i < svc.length; i++) svc[i] = db.services.get(i).id + " - " + db.services.get(i).name;
        return Arrays.asList(FieldSpec.readonly("Repair Job ID"),
                j == null ? FieldSpec.combo("Motorcycle", motos) : FieldSpec.readonly("Motorcycle"),
                FieldSpec.combo("Service Type", svc), FieldSpec.combo("Assigned Mechanic", mechanicOptions(j)),
                FieldSpec.text("Date Received (yyyy-MM-dd)"), FieldSpec.text("Expected Completion (yyyy-MM-dd)"),
                FieldSpec.area("Problem / Complaint"), FieldSpec.area("Diagnosis"), FieldSpec.area("Recommended Repair"),
                FieldSpec.text("Labor Cost (blank = service price)"), FieldSpec.combo("Repair Status", RepairJob.STATUSES));
    }
    @Override protected String[] valuesOf(RepairJob j) {
        if (j == null) return new String[]{db.peekId("JOB"), "", "", "(Unassigned)", Fmt.today(), LocalDate.now().plusDays(3).format(Fmt.DATE), "", "", "", "", "Waiting for Inspection"};
        Service s = db.service(j.serviceId); Mechanic m = db.mechanic(j.mechanicId);
        return new String[]{j.id, j.motorcycleId + " - " + db.motoLabel(j.motorcycleId) + " - " + db.customerName(j.customerId),
            s == null ? "" : s.id + " - " + s.name, m == null ? "(Unassigned)" : m.id + " - " + m.fullName, j.dateReceived, j.expectedDate,
            j.complaint, j.diagnosis, j.recommended, String.valueOf(j.laborCost), j.status};
    }
    @Override protected String save(RepairJob j, String[] v) {
        Motorcycle m = j == null ? db.motorcycle(Fmt.idOf(v[1])) : db.motorcycle(j.motorcycleId);
        if (m == null) return "Please select a motorcycle.";
        Service s = db.service(Fmt.idOf(v[2]));
        if (s == null) return "Please select a service type.";
        LocalDate rec = Validator.date(v[4]), exp = Validator.date(v[5]);
        if (rec == null) return "Date received is invalid. Use yyyy-MM-dd.";
        if (exp == null) return "Expected completion date is invalid. Use yyyy-MM-dd.";
        if (exp.isBefore(rec)) return "Expected completion cannot be before the date received.";
        String e = Validator.required("Problem / complaint", v[6]);
        if (e != null) return e;
        double labor = s.price;
        if (!v[9].trim().isEmpty()) {
            Double d = Validator.money(v[9]);
            if (d == null) return "Labor cost must be a valid non-negative number.";
            labor = d;
        }
        if (j != null && db.invoiceForJob(j.id) != null && Math.abs(labor - j.laborCost) > 0.004)
            return "A bill was already generated for this job, so the labor cost can no longer be changed.";
        if ((e = statusError(j, v[10])) != null) return e;
        boolean isNew = j == null;
        if (isNew) { j = new RepairJob(); j.id = db.nextId("JOB"); j.customerId = m.customerId; j.motorcycleId = m.id; db.jobs.add(j); }
        j.serviceId = s.id;
        j.mechanicId = v[3].startsWith("(") ? null : Fmt.idOf(v[3]);
        j.dateReceived = v[4].trim(); j.expectedDate = v[5].trim();
        j.complaint = v[6]; j.diagnosis = v[7]; j.recommended = v[8]; j.laborCost = labor;
        applyStatus(j, v[10]);
        return null;
    }

    // ---- status rules ----
    private String statusError(RepairJob j, String status) {
        if (j == null) return null;
        Invoice inv = db.invoiceForJob(j.id);
        if (status.equals("Released") && (inv == null || !inv.paymentStatus(j).equals("Paid")))
            return "A job can only be Released after its bill is generated and fully paid.";
        if (status.equals("Cancelled") && inv != null) return "A job with a generated bill cannot be cancelled.";
        return null;
    }
    private void applyStatus(RepairJob j, String status) {
        if (status.equals("Cancelled") && !j.status.equals("Cancelled")) {
            for (PartUsage u : j.parts) { SparePart p = db.part(u.partId); if (p != null) p.stock += u.qty; }
            j.parts.clear();
        }
        j.status = status;
        db.syncMechanics();
    }
    @Override protected String deleteError(RepairJob j) {
        return db.invoiceForJob(j.id) != null ? "This job already has a bill and cannot be deleted." : null;
    }
    @Override protected void delete(RepairJob j) {
        for (PartUsage u : j.parts) { SparePart p = db.part(u.partId); if (p != null) p.stock += u.qty; }
        db.jobs.remove(j); db.syncMechanics();
    }
    @Override protected void changed() { db.syncMechanics(); super.changed(); }

    private void updateStatus() {
        RepairJob j = selected(); if (j == null) return;
        Object o = JOptionPane.showInputDialog(this, "Select the new repair status for " + j.id + ":", "Update Repair Status",
                JOptionPane.QUESTION_MESSAGE, null, RepairJob.STATUSES, j.status);
        if (o == null) return;
        String err = statusError(j, o.toString());
        if (err != null) { warn(err); return; }
        applyStatus(j, o.toString()); changed();
    }

    private void generateBill() {
        RepairJob j = selected(); if (j == null) return;
        if (!j.isDone()) { warn("A bill can be generated once the repair is Completed, Ready for Pickup or Released."); return; }
        if (db.invoiceForJob(j.id) != null) { info("This job already has invoice " + db.invoiceForJob(j.id).id + ". Open Billing to manage it."); return; }
        Invoice i = new Invoice(); i.id = db.nextId("INV"); i.jobId = j.id; i.date = Fmt.today();
        db.invoices.add(i); changed();
        info("Invoice " + i.id + " generated. Total: " + Fmt.money(i.total(j)) + ". Open Billing to add charges or record payment.");
    }

    private void viewDetails() { RepairJob j = selected(); if (j != null) TextViewer.show(this, "Repair Job " + j.id, details(j)); }

    /** Full text description of a repair job (shared with Service History). */
    public static String details(RepairJob j) {
        sikadmotorshop.data.DataStore db = sikadmotorshop.data.DataStore.get();
        StringBuilder sb = new StringBuilder();
        sb.append("Repair Job ID   : ").append(j.id).append('\n');
        sb.append("Customer        : ").append(j.customerId).append(" - ").append(db.customerName(j.customerId)).append('\n');
        sb.append("Motorcycle      : ").append(db.motoLabel(j.motorcycleId)).append('\n');
        sb.append("Service Type    : ").append(db.serviceName(j.serviceId)).append('\n');
        sb.append("Mechanic        : ").append(db.mechanicName(j.mechanicId)).append('\n');
        sb.append("Date Received   : ").append(j.dateReceived).append('\n');
        sb.append("Expected Finish : ").append(j.expectedDate).append('\n');
        sb.append("Status          : ").append(j.status).append("\n\n");
        sb.append("Complaint       : ").append(j.complaint).append('\n');
        sb.append("Diagnosis       : ").append(j.diagnosis.isEmpty() ? "(not yet diagnosed)" : j.diagnosis).append('\n');
        sb.append("Recommended     : ").append(j.recommended.isEmpty() ? "-" : j.recommended).append("\n\nParts Used:\n");
        if (j.parts.isEmpty()) sb.append("  (none)\n");
        for (PartUsage u : j.parts) sb.append(String.format("  %-24s x%-3d %12s%n", u.partName, u.qty, Fmt.money(u.total())));
        sb.append(String.format("%nLabor Cost : %12s%nParts Cost : %12s%nTOTAL COST : %12s%n", Fmt.money(j.laborCost), Fmt.money(j.partsCost()), Fmt.money(j.totalCost())));
        Invoice inv = db.invoiceForJob(j.id);
        sb.append("Payment    : ").append(inv == null ? "No bill yet" : inv.id + " (" + inv.paymentStatus(j) + ")").append('\n');
        return sb.toString();
    }

    // ---- parts used ----
    private void manageParts() {
        final RepairJob j = selected(); if (j == null) return;
        if (db.invoiceForJob(j.id) != null) { warn("A bill was already generated for this job. Parts can no longer be changed."); return; }
        if (j.status.equals("Released") || j.status.equals("Cancelled")) { warn("Parts cannot be changed on a " + j.status + " job."); return; }
        final JDialog d = new JDialog(SwingUtilities.getWindowAncestor(this), "Parts Used", Dialog.ModalityType.APPLICATION_MODAL);
        final DefaultTableModel pm = new DefaultTableModel(new String[]{"Part ID", "Part Name", "Qty", "Unit Price", "Line Total"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        final JTable pt = new JTable(pm); Theme.styleTable(pt);
        final JComboBox<String> cb = new JComboBox<String>();
        final JSpinner qty = new JSpinner(new SpinnerNumberModel(1, 1, 1000, 1));
        final Runnable reload = () -> {
            pm.setRowCount(0);
            for (PartUsage u : j.parts) pm.addRow(new Object[]{u.partId, u.partName, u.qty, Fmt.money(u.unitPrice), Fmt.money(u.total())});
            d.setTitle("Parts Used - " + j.id + "   |   Parts cost: " + Fmt.money(j.partsCost()));
            cb.removeAllItems();
            for (SparePart p : db.parts) if (p.stock > 0) cb.addItem(p.id + " - " + p.name + " (" + p.brand + ") | stock " + p.stock + " | " + Fmt.money(p.unitPrice));
        };
        JButton add = Theme.primary("Add Part"), rem = Theme.danger("Remove Selected"), close = Theme.dark("Close");
        add.addActionListener(e -> {
            if (cb.getSelectedItem() == null) { JOptionPane.showMessageDialog(d, "No parts in stock."); return; }
            SparePart p = db.part(Fmt.idOf(cb.getSelectedItem().toString()));
            int q = (Integer) qty.getValue();
            if (p == null || q > p.stock) { JOptionPane.showMessageDialog(d, "Not enough stock. Available: " + (p == null ? 0 : p.stock)); return; }
            p.stock -= q;
            PartUsage use = null;
            for (PartUsage u : j.parts) if (u.partId.equals(p.id)) use = u;
            if (use == null) { use = new PartUsage(); use.partId = p.id; use.partName = p.name; use.unitPrice = p.unitPrice; j.parts.add(use); }
            use.qty += q;
            reload.run();
        });
        rem.addActionListener(e -> {
            int r = pt.getSelectedRow();
            if (r < 0) { JOptionPane.showMessageDialog(d, "Select a part row first."); return; }
            PartUsage u = j.parts.remove(pt.convertRowIndexToModel(r));
            SparePart p = db.part(u.partId); if (p != null) p.stock += u.qty;
            reload.run();
        });
        close.addActionListener(e -> d.dispose());
        d.addWindowListener(new WindowAdapter() { @Override public void windowClosed(WindowEvent e) { changed(); } });
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        cb.setPrototypeDisplayValue("PRT-0000 - XXXXXXXXXXXXXXXXXXXX (XXXXXXXX) | stock 000 | P00,000.00");
        bar.add(cb); bar.add(new JLabel("Qty:")); bar.add(qty); bar.add(add); bar.add(rem); bar.add(close);
        d.getContentPane().add(new JScrollPane(pt), BorderLayout.CENTER);
        d.getContentPane().add(bar, BorderLayout.SOUTH);
        reload.run();
        d.setSize(1000, 420); d.setLocationRelativeTo(this); d.setVisible(true);
    }
}
