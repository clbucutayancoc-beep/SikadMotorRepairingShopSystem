package sikadmotorshop.ui;

import java.awt.*;
import javax.swing.*;

/** Shows multi-line read-only text (bills, job details) in a dialog. */
public final class TextViewer {
    private TextViewer() {}
    public static void show(Component parent, String title, String text) {
        JTextArea a = new JTextArea(text, 22, 52);
        a.setEditable(false); a.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13)); a.setCaretPosition(0);
        a.setMargin(new Insets(10, 12, 10, 12));
        JOptionPane.showMessageDialog(parent, new JScrollPane(a), title, JOptionPane.PLAIN_MESSAGE);
    }
}
