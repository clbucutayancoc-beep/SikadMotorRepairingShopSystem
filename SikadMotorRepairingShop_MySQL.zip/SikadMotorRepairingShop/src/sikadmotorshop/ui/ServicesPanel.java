package sikadmotorshop.ui;

import java.util.*;
import sikadmotorshop.model.*;
import sikadmotorshop.util.*;

/** Manager: motorcycle repair service catalog (Add / Edit / Delete / Search / View details). */
public class ServicesPanel extends CrudPanel<Service> {
    public ServicesPanel() {
        super("Service Management");
        addAction("View Details", Theme.BLUE, this::viewDetails);
        buildButtons();
    }
    @Override protected String singular() { return "Service"; }
    @Override protected String[] columns() { return new String[]{"Service ID", "Service Name", "Description", "Est. Price", "Est. Duration", "Service Status"}; }
    @Override protected int[] widths() { return new int[]{90, 170, 320, 100, 110, 110}; }
    @Override protected List<Service> items() { return db.services; }
    @Override protected Object[] row(Service s) { return new Object[]{s.id, s.name, s.description, Fmt.money(s.price), s.duration, s.status}; }
    @Override protected List<FieldSpec> fields(Service s) {
        return Arrays.asList(FieldSpec.readonly("Service ID"), FieldSpec.text("Service Name"), FieldSpec.area("Description"),
                FieldSpec.text("Estimated Price"), FieldSpec.text("Estimated Duration"), FieldSpec.combo("Service Status", "Active", "Inactive"));
    }
    @Override protected String[] valuesOf(Service s) {
        if (s == null) return new String[]{db.peekId("SRV"), "", "", "", "", "Active"};
        return new String[]{s.id, s.name, s.description, String.valueOf(s.price), s.duration, s.status};
    }
    @Override protected String save(Service s, String[] v) {
        String e;
        if ((e = Validator.required("Service name", v[1])) != null) return e;
        if ((e = Validator.required("Estimated duration", v[4])) != null) return e;
        Double price = Validator.money(v[3]);
        if (price == null) return "Estimated price must be a valid non-negative number.";
        for (Service o : db.services) if (o != s && o.name.equalsIgnoreCase(v[1])) return "A service with this name already exists.";
        if (s == null) { s = new Service(); s.id = db.nextId("SRV"); db.services.add(s); }
        s.name = v[1]; s.description = v[2]; s.price = price; s.duration = v[4]; s.status = v[5];
        return null;
    }
    @Override protected String deleteError(Service s) {
        for (Appointment a : db.appointments) if (s.id.equals(a.serviceId)) return "This service is used by appointments. Set it to Inactive instead.";
        for (RepairJob j : db.jobs) if (s.id.equals(j.serviceId)) return "This service is used by repair jobs. Set it to Inactive instead.";
        return null;
    }
    @Override protected void delete(Service s) { db.services.remove(s); }
    private void viewDetails() {
        Service s = selected(); if (s == null) return;
        info("Service ID: " + s.id + "\nName: " + s.name + "\nDescription: " + s.description + "\nEstimated Price: "
                + Fmt.money(s.price) + "\nEstimated Duration: " + s.duration + "\nStatus: " + s.status);
    }
}
