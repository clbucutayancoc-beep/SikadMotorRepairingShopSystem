package sikadmotorshop.ui;

import java.time.LocalDate;
import java.util.*;
import javax.swing.JOptionPane;
import sikadmotorshop.model.*;
import sikadmotorshop.util.*;

/** Appointments. Manager (scope == null) manages all; customer books and cancels their own. */
public class AppointmentPanel extends CrudPanel<Appointment> {
    private final Customer scope;

    public AppointmentPanel(Customer scope) {
        super(scope == null ? "Appointment Management" : "My Appointments");
        this.scope = scope;
        allowEdit = false; allowDelete = false;
        if (scope == null) {
            addAction("Approve", Theme.GREEN, this::approve);
            addAction("Reject / Cancel", Theme.RED, this::cancel);
            addAction("Reschedule", Theme.BLUE, this::reschedule);
            addAction("Assign Mechanic", new java.awt.Color(73, 80, 87), this::assign);
            addAction("Mark Completed", Theme.GREEN, this::complete);
            addAction("Create Repair Job", Theme.ACCENT, this::createJob);
        } else {
            addAction("Cancel Appointment", Theme.RED, this::cancel);
        }
        buildButtons();
    }
    @Override protected String singular() { return "Appointment"; }
    @Override protected String addLabel() { return "Book Appointment"; }
    @Override protected String[] columns() { return new String[]{"Appointment ID", "Customer", "Motorcycle", "Service", "Date", "Time", "Mechanic", "Concern", "Appointment Status"}; }
    @Override protected int[] widths() { return new int[]{110, 140, 190, 150, 90, 60, 130, 220, 130}; }
    @Override protected List<Appointment> items() {
        List<Appointment> l = new ArrayList<Appointment>();
        for (Appointment a : db.appointments) if (scope == null || a.customerId.equals(scope.id)) l.add(a);
        Collections.reverse(l);
        return l;
    }
    @Override protected Object[] row(Appointment a) {
        return new Object[]{a.id, db.customerName(a.customerId), db.motoLabel(a.motorcycleId), db.serviceName(a.serviceId), a.date, a.time,
            db.mechanicName(a.mechanicId), a.concern, a.status};
    }

    private String[] motoOptions() {
        List<String> l = new ArrayList<String>();
        for (Motorcycle m : db.motorcycles)
            if (scope == null || m.customerId.equals(scope.id))
                l.add(m.id + " - " + m.label() + (scope == null ? " - " + db.customerName(m.customerId) : ""));
        return l.toArray(new String[0]);
    }
    private String[] serviceOptions() {
        List<String> l = new ArrayList<String>();
        for (Service s : db.services) if (s.status.equals("Active")) l.add(s.id + " - " + s.name);
        return l.toArray(new String[0]);
    }
    @Override protected List<FieldSpec> fields(Appointment a) {
        String[] motos = motoOptions();
        if (motos.length == 0) { warn(scope == null ? "No motorcycles are registered yet." : "Please register your motorcycle first (My Motorcycles)."); return null; }
        String[] svc = serviceOptions();
        if (svc.length == 0) { warn("No active services are available."); return null; }
        return Arrays.asList(FieldSpec.readonly("Appointment ID"), FieldSpec.combo("Motorcycle", motos), FieldSpec.combo("Service", svc),
                FieldSpec.text("Date (yyyy-MM-dd)"), FieldSpec.combo("Time", Appointment.TIMES), FieldSpec.area("Problem / Concern"));
    }
    @Override protected String[] valuesOf(Appointment a) {
        return new String[]{db.peekId("APT"), "", "", LocalDate.now().plusDays(1).format(Fmt.DATE), "09:00", ""};
    }
    private String slotError(String date, String time, String motoId, String ignoreId) {
        LocalDate d = Validator.date(date);
        if (d == null) return "Appointment date is invalid. Use the format yyyy-MM-dd (example: 2026-10-15).";
        if (d.isBefore(LocalDate.now())) return "Appointment date cannot be in the past.";
        for (Appointment o : db.appointments)
            if (o.isOpen() && !o.id.equals(ignoreId) && o.motorcycleId.equals(motoId) && o.date.equals(date) && o.time.equals(time))
                return "This motorcycle already has an appointment at that date and time.";
        return null;
    }
    @Override protected String save(Appointment a, String[] v) {
        Motorcycle m = db.motorcycle(Fmt.idOf(v[1]));
        if (m == null) return "Please select a motorcycle.";
        if (scope != null && !m.customerId.equals(scope.id)) return "You can only book for your own motorcycle.";
        Service s = db.service(Fmt.idOf(v[2]));
        if (s == null) return "Please select a service.";
        String e = Validator.required("Problem / concern", v[5]);
        if (e != null) return e;
        String date = v[3].trim();
        if ((e = slotError(date, v[4], m.id, null)) != null) return e;
        Appointment n = new Appointment();
        n.id = db.nextId("APT"); n.customerId = m.customerId; n.motorcycleId = m.id; n.serviceId = s.id;
        n.date = date; n.time = v[4]; n.concern = v[5];
        db.appointments.add(n);
        return null;
    }

    private void approve() {
        Appointment a = selected(); if (a == null) return;
        if (!a.status.equals("Pending") && !a.status.equals("Rescheduled")) { warn("Only Pending or Rescheduled appointments can be approved."); return; }
        a.status = "Approved"; changed(); info("Appointment " + a.id + " approved.");
    }
    private void cancel() {
        Appointment a = selected(); if (a == null) return;
        if (!a.isOpen()) { warn("This appointment is already " + a.status + " and cannot be cancelled."); return; }
        if (db.jobForAppointment(a.id) != null) { warn("A repair job was already created for this appointment. It can no longer be cancelled here."); return; }
        if (JOptionPane.showConfirmDialog(this, "Cancel appointment " + a.id + "?", "Confirm", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        a.status = "Cancelled"; changed();
    }
    private void reschedule() {
        Appointment a = selected(); if (a == null) return;
        if (!a.isOpen()) { warn("Only open appointments can be rescheduled."); return; }
        boolean ok = FormDialog.show(this, "Reschedule " + a.id, Arrays.asList(FieldSpec.text("New Date (yyyy-MM-dd)"), FieldSpec.combo("New Time", Appointment.TIMES)),
                new String[]{a.date, a.time}, v -> {
                    String err = slotError(v[0].trim(), v[1], a.motorcycleId, a.id);
                    if (err != null) return err;
                    a.date = v[0].trim(); a.time = v[1]; a.status = "Rescheduled";
                    return null;
                });
        if (ok) { changed(); info("Appointment rescheduled."); }
    }
    private void assign() {
        Appointment a = selected(); if (a == null) return;
        if (!a.isOpen()) { warn("Mechanics can only be assigned to open appointments."); return; }
        db.syncMechanics();
        List<String> opts = new ArrayList<String>();
        for (Mechanic m : db.mechanics) if (m.status.equals("Available") || m.status.equals("Busy")) opts.add(m.id + " - " + m.fullName + " (" + m.specialization + ", " + m.status + ")");
        if (opts.isEmpty()) { warn("No mechanics are available. Add or activate a mechanic first."); return; }
        boolean ok = FormDialog.show(this, "Assign Mechanic", Arrays.asList(FieldSpec.combo("Mechanic", opts.toArray(new String[0]))), new String[]{""},
                v -> { a.mechanicId = Fmt.idOf(v[0]); return null; });
        if (ok) { changed(); info("Mechanic assigned."); }
    }
    private void complete() {
        Appointment a = selected(); if (a == null) return;
        if (!a.status.equals("Approved") && !a.status.equals("Rescheduled")) { warn("Only Approved or Rescheduled appointments can be marked completed."); return; }
        a.status = "Completed"; changed();
    }
    private void createJob() {
        Appointment a = selected(); if (a == null) return;
        if (!a.status.equals("Approved") && !a.status.equals("Rescheduled")) { warn("Approve the appointment first (status must be Approved or Rescheduled)."); return; }
        if (db.jobForAppointment(a.id) != null) { warn("A repair job already exists for this appointment: " + db.jobForAppointment(a.id).id); return; }
        Service s = db.service(a.serviceId);
        RepairJob j = new RepairJob();
        j.id = db.nextId("JOB"); j.appointmentId = a.id; j.customerId = a.customerId; j.motorcycleId = a.motorcycleId; j.serviceId = a.serviceId;
        j.mechanicId = a.mechanicId; j.dateReceived = Fmt.today(); j.expectedDate = LocalDate.now().plusDays(3).format(Fmt.DATE);
        j.complaint = a.concern; j.laborCost = s == null ? 0 : s.price; j.status = "Waiting for Inspection";
        db.jobs.add(j); db.syncMechanics(); changed();
        info("Repair job " + j.id + " created. Open Repair Jobs to diagnose, add parts and update the status.");
    }
}
