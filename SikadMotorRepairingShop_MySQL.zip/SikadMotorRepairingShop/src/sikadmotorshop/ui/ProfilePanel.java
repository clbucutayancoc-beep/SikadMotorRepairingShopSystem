package sikadmotorshop.ui;

import java.awt.*;
import javax.swing.*;
import sikadmotorshop.data.DataStore;
import sikadmotorshop.model.Customer;
import sikadmotorshop.util.*;

/** Customer: edit own profile and password. */
public class ProfilePanel extends JPanel implements Refreshable {
    private final DataStore db = DataStore.get();
    private final Customer me;
    private final JTextField id = new JTextField(24), firstName = new JTextField(24), lastName = new JTextField(24), address = new JTextField(24), contact = new JTextField(24),
        email = new JTextField(24), username = new JTextField(24);
    private final JPasswordField pass = new JPasswordField(24), confirm = new JPasswordField(24);

    public ProfilePanel(Customer me) {
        super(new BorderLayout(0, 12));
        this.me = me;
        setBackground(Theme.BG); setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));
        add(Theme.title("My Profile"), BorderLayout.NORTH);
        JPanel form = new JPanel(new GridBagLayout()); form.setBackground(Color.WHITE);
        form.setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));
        id.setEditable(false); id.setBackground(new Color(233, 236, 239));
        String[] labels = {"Customer ID", "First Name", "Last Name", "Address", "Contact Number", "Email", "Username", "New Password (blank = keep)", "Confirm New Password"};
        JComponent[] f = {id, firstName, lastName, address, contact, email, username, pass, confirm};
        pass.setToolTipText("8-64 characters: uppercase, lowercase, number, and special character");
        confirm.setToolTipText("Re-enter the same strong password");
        GridBagConstraints gc = new GridBagConstraints(); gc.insets = new Insets(6, 4, 6, 4); gc.anchor = GridBagConstraints.WEST;
        for (int i = 0; i < f.length; i++) {
            gc.gridx = 0; gc.gridy = i; JLabel l = new JLabel(labels[i]); l.setFont(Theme.BOLD); form.add(l, gc);
            gc.gridx = 1; form.add(f[i], gc);
        }
        JButton save = Theme.primary("SAVE CHANGES"); save.addActionListener(e -> save());
        gc.gridx = 1; gc.gridy = f.length; form.add(save, gc);
        JPanel wrap = new JPanel(new FlowLayout(FlowLayout.LEFT)); wrap.setOpaque(false); wrap.add(form);
        add(wrap, BorderLayout.CENTER);
        refresh();
    }
    @Override public void refresh() {
        id.setText(me.id); firstName.setText(me.firstName); lastName.setText(me.lastName); address.setText(me.address); contact.setText(me.contact);
        email.setText(me.email); username.setText(me.username); pass.setText(""); confirm.setText("");
    }
    private void save() {
        String p = new String(pass.getPassword()), c = new String(confirm.getPassword());
        String err = Validator.customerError(firstName.getText().trim(), lastName.getText().trim(), address.getText().trim(), contact.getText().trim(), email.getText().trim(),
                username.getText().trim(), p, c, false, me.id);
        if (err != null) { JOptionPane.showMessageDialog(this, err, "Validation Error", JOptionPane.WARNING_MESSAGE); return; }
        me.firstName = firstName.getText().trim(); me.lastName = lastName.getText().trim(); me.fullName = me.getFullName(); me.address = address.getText().trim(); me.contact = contact.getText().trim();
        me.email = email.getText().trim(); me.username = username.getText().trim();
        if (!p.isEmpty()) me.passwordHash = Security.hash(p);
        db.save(); refresh();
        JOptionPane.showMessageDialog(this, "Profile updated successfully.");
    }
}
