package sikadmotorshop.ui;

import java.awt.*;
import javax.swing.*;
import sikadmotorshop.data.DataStore;
import sikadmotorshop.model.*;
import sikadmotorshop.util.Fmt;

/** Customer dashboard: only the logged-in customer's own statistics. */
public class CustomerDashboardPanel extends JPanel implements Refreshable {
    private final DataStore db = DataStore.get();
    private final Customer me;
    private final JLabel welcome = new JLabel();
    private final Theme.StatCard motos = new Theme.StatCard("REGISTERED MOTORCYCLES", Theme.TEXT), upcoming = new Theme.StatCard("UPCOMING APPOINTMENTS", Theme.BLUE),
        active = new Theme.StatCard("ACTIVE REPAIRS", Theme.ACCENT), done = new Theme.StatCard("COMPLETED SERVICES", Theme.GREEN),
        balance = new Theme.StatCard("OUTSTANDING BALANCE", Theme.RED);

    public CustomerDashboardPanel(Customer me) {
        super(new BorderLayout(0, 18));
        this.me = me;
        setBackground(Theme.BG); setBorder(BorderFactory.createEmptyBorder(24, 28, 24, 28));
        JPanel head = new JPanel(new GridLayout(2, 1)); head.setOpaque(false);
        JLabel t = new JLabel(Theme.BRAND); t.setFont(new Font("Segoe UI", Font.BOLD, 24)); t.setForeground(Theme.TEXT);
        welcome.setFont(new Font("Segoe UI", Font.PLAIN, 16)); welcome.setForeground(Theme.MUTED);
        head.add(t); head.add(welcome);
        add(head, BorderLayout.NORTH);
        JPanel grid = new JPanel(new GridLayout(0, 3, 16, 16)); grid.setOpaque(false);
        grid.add(motos); grid.add(upcoming); grid.add(active); grid.add(done); grid.add(balance);
        JPanel wrap = new JPanel(new BorderLayout()); wrap.setOpaque(false); wrap.add(grid, BorderLayout.NORTH);
        add(wrap, BorderLayout.CENTER);
        refresh();
    }
    @Override public void refresh() {
        welcome.setText("Welcome, " + me.getFullName());
        int m = 0, up = 0, act = 0, dn = 0; double bal = 0;
        for (Motorcycle x : db.motorcycles) if (x.customerId.equals(me.id)) m++;
        for (Appointment a : db.appointments) if (a.customerId.equals(me.id) && a.isOpen() && a.date.compareTo(Fmt.today()) >= 0) up++;
        for (RepairJob j : db.jobs) if (j.customerId.equals(me.id)) { if (j.isActive()) act++; if (j.isDone()) dn++; }
        for (Invoice i : db.invoices) { RepairJob j = db.job(i.jobId); if (j != null && j.customerId.equals(me.id)) bal += Math.max(0, i.balance(j)); }
        motos.set(String.valueOf(m)); upcoming.set(String.valueOf(up)); active.set(String.valueOf(act)); done.set(String.valueOf(dn)); balance.set(Fmt.money(bal));
    }
}
