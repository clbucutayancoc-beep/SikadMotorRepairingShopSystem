package sikadmotorshop.ui;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import sikadmotorshop.data.DataStore;

/**
 * Reusable table panel with Search / Add / Edit / Delete / Refresh. Subclasses supply the columns, rows,
 * form fields and save/delete rules.
 */
public abstract class CrudPanel<T> extends JPanel implements Refreshable {
    protected final DataStore db = DataStore.get();
    protected final DefaultTableModel model;
    protected final JTable table;
    protected final JTextField search = new JTextField(18);
    protected final JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
    protected final List<T> shown = new ArrayList<T>();
    protected boolean allowAdd = true, allowEdit = true, allowDelete = true;

    protected abstract String[] columns();
    protected abstract List<T> items();
    protected abstract Object[] row(T t);
    protected String heading() { return ""; }
    protected int[] widths() { return null; }

    /** Form fields for add (existing == null) or edit. */
    protected List<FieldSpec> fields(T existing) { return null; }
    protected String[] valuesOf(T existing) { return null; }
    /** Validate and apply the values. Return an error message, or null when saved. */
    protected String save(T existing, String[] v) { return "Not supported."; }
    /** Return an error message if the record cannot be deleted. */
    protected String deleteError(T t) { return null; }
    protected void delete(T t) {}
    protected String singular() { return "record"; }
    protected String addLabel() { return "Add"; }
    protected String editLabel() { return "Edit"; }

    protected CrudPanel(String title) {
        super(new BorderLayout(0, 12));
        setBackground(Theme.BG);
        setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));
        model = new DefaultTableModel(columns(), 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        Theme.styleTable(table);
        for (int i = 0; i < model.getColumnCount(); i++)
            if (model.getColumnName(i).endsWith("Status"))
                table.getColumnModel().getColumn(i).setCellRenderer(new Theme.StatusRenderer());
        int[] w = widths();
        if (w != null) for (int i = 0; i < w.length && i < table.getColumnCount(); i++) table.getColumnModel().getColumn(i).setPreferredWidth(w[i]);

        JPanel top = new JPanel(new BorderLayout(0, 10)); top.setOpaque(false);
        JPanel head = new JPanel(new BorderLayout()); head.setOpaque(false);
        head.add(Theme.title(title), BorderLayout.WEST);
        JPanel sp = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0)); sp.setOpaque(false);
        sp.add(new JLabel("Search:")); sp.add(search);
        head.add(sp, BorderLayout.EAST);
        actions.setOpaque(false);
        top.add(head, BorderLayout.NORTH); top.add(actions, BorderLayout.CENTER);
        add(top, BorderLayout.NORTH);
        JScrollPane sc = new JScrollPane(table); sc.getViewport().setBackground(Color.WHITE);
        add(sc, BorderLayout.CENTER);
        search.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { refresh(); }
            public void removeUpdate(DocumentEvent e) { refresh(); }
            public void changedUpdate(DocumentEvent e) { refresh(); }
        });
    }

    /** Call at the end of the subclass constructor. */
    protected void buildButtons() {
        if (allowAdd) { JButton b = Theme.primary(addLabel()); b.addActionListener(e -> addRecord()); actions.add(b); }
        if (allowEdit) { JButton b = Theme.dark(editLabel()); b.addActionListener(e -> editSelected()); actions.add(b); }
        if (allowDelete) { JButton b = Theme.danger("Delete"); b.addActionListener(e -> deleteSelected()); actions.add(b); }
        JButton r = Theme.dark("Refresh"); r.addActionListener(e -> { search.setText(""); refresh(); }); actions.add(r);
        refresh();
    }

    protected JButton addAction(String text, Color color, Runnable r) {
        JButton b = Theme.button(text, color); b.addActionListener(e -> r.run()); actions.add(b); return b;
    }

    @Override public void refresh() {
        String q = search.getText().trim().toLowerCase();
        model.setRowCount(0); shown.clear();
        for (T t : items()) {
            Object[] r = row(t);
            if (!q.isEmpty()) {
                boolean hit = false;
                for (Object o : r) if (o != null && o.toString().toLowerCase().contains(q)) { hit = true; break; }
                if (!hit) continue;
            }
            shown.add(t); model.addRow(r);
        }
    }

    /** Selected record or null (shows a message). */
    protected T selected() {
        int r = table.getSelectedRow();
        if (r < 0) { JOptionPane.showMessageDialog(this, "Please select a row first.", "No Selection", JOptionPane.INFORMATION_MESSAGE); return null; }
        return shown.get(table.convertRowIndexToModel(r));
    }

    protected void changed() { db.save(); refresh(); }

    public void addRecord() {
        List<FieldSpec> f = fields(null);
        if (f == null) return;
        if (FormDialog.show(this, "Add " + singular(), f, valuesOf(null), v -> save(null, v))) {
            changed();
            JOptionPane.showMessageDialog(this, singular() + " saved successfully.");
        }
    }

    protected void editSelected() {
        T t = selected(); if (t == null) return;
        List<FieldSpec> f = fields(t);
        if (f == null) return;
        if (FormDialog.show(this, "Edit " + singular(), f, valuesOf(t), v -> save(t, v))) {
            changed();
            JOptionPane.showMessageDialog(this, singular() + " updated successfully.");
        }
    }

    protected void deleteSelected() {
        T t = selected(); if (t == null) return;
        String err = deleteError(t);
        if (err != null) { JOptionPane.showMessageDialog(this, err, "Cannot Delete", JOptionPane.WARNING_MESSAGE); return; }
        if (JOptionPane.showConfirmDialog(this, "Delete the selected " + singular() + "?", "Confirm Delete",
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION) {
            delete(t); changed();
        }
    }

    protected void info(String m) { JOptionPane.showMessageDialog(this, m); }
    protected void warn(String m) { JOptionPane.showMessageDialog(this, m, "Notice", JOptionPane.WARNING_MESSAGE); }
}
