package sikadmotorshop.ui;

import java.awt.*;
import javax.swing.*;
import sikadmotorshop.data.DataStore;
import sikadmotorshop.model.Mechanic;
import sikadmotorshop.util.Security;

/** Staff-facing login for Manager, Staff, and Mechanic accounts. No customer self-login/booking. */
public class LoginFrame extends JFrame {
    private final JTextField username = new JTextField(20);
    private final JPasswordField password = new JPasswordField(20);
    private final JRadioButton managerStaff = new JRadioButton("Manager / Staff"), mechanic = new JRadioButton("Mechanic");

    public LoginFrame() {
        super("Sikad Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 550); setResizable(false); setLocationRelativeTo(null);
        setLayout(new GridLayout(1, 2));

        JPanel left = new JPanel(new GridBagLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Theme.ACCENT); g2.fillOval(getWidth() / 2 - 50, 55, 100, 100);
                g2.setColor(Theme.SIDEBAR); g2.fillOval(getWidth() / 2 - 34, 71, 68, 68);
                g2.setColor(Color.WHITE); g2.setFont(new Font("Segoe UI", Font.BOLD, 44));
                g2.drawString("S", getWidth() / 2 - 14, 120); g2.dispose();
            }
        };
        left.setBackground(Theme.SIDEBAR);
        JLabel brand = new JLabel("<html><div style='text-align:center;width:300px;padding-top:145px'><span style='font-size:26px;color:#E65100'><b>SIKAD</b></span><br>"
                + "<span style='font-size:15px;color:white'><b>MOTOR REPAIRING<br>SHOP SERVICES</b></span><br><br>"
                + "<span style='font-size:11px;color:#ADB5BD'>Walk-in repairs, parts, service and billing<br>managed in one place.</span></div></html>");
        left.add(brand);

        JPanel right = new JPanel(new GridBagLayout()); right.setBackground(Color.WHITE);
        GridBagConstraints gc = new GridBagConstraints(); gc.gridx = 0; gc.insets = new Insets(5, 40, 5, 40); gc.fill = GridBagConstraints.HORIZONTAL;
        JLabel h = Theme.title("Sikad Login"); gc.gridy = 0; right.add(h, gc);
        ButtonGroup bg = new ButtonGroup(); bg.add(managerStaff); bg.add(mechanic); managerStaff.setSelected(true);
        managerStaff.setBackground(Color.WHITE); mechanic.setBackground(Color.WHITE);
        JPanel roles = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0)); roles.setBackground(Color.WHITE);
        roles.add(new JLabel("Login as:")); roles.add(managerStaff); roles.add(mechanic);
        gc.gridy = 1; right.add(roles, gc);
        gc.gridy = 2; right.add(label("Username / Mechanic ID"), gc); gc.gridy = 3; right.add(username, gc);
        gc.gridy = 4; right.add(label("Password"), gc); gc.gridy = 5; right.add(password, gc);
        JLabel hint = new JLabel("Walk-in workflow: Manager / Staff handles customers, units, repairs, billing and inventory.");
        hint.setForeground(Theme.MUTED); hint.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        gc.gridy = 6; right.add(hint, gc);
        JButton login = Theme.primary("LOGIN"), exit = Theme.button("EXIT", Theme.RED);
        gc.gridy = 7; gc.insets = new Insets(14, 40, 5, 40); right.add(login, gc);
        gc.gridy = 8; gc.insets = new Insets(5, 40, 5, 40); right.add(exit, gc);
        JLabel dbStatus = new JLabel(DataStore.get().storageDescription());
        dbStatus.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        dbStatus.setForeground(DataStore.get().usingDatabase() ? new Color(0x2E7D32) : Theme.RED);
        gc.gridy = 9; gc.insets = new Insets(8, 40, 5, 40); right.add(dbStatus, gc);
        add(left); add(right);
        login.addActionListener(e -> doLogin()); password.addActionListener(e -> doLogin());
        exit.addActionListener(e -> { if (JOptionPane.showConfirmDialog(this, "Exit the application?", "Exit", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) System.exit(0); });
        getRootPane().setDefaultButton(login);
    }
    private JLabel label(String t) { JLabel l = new JLabel(t); l.setFont(Theme.BOLD); return l; }
    public void prefill(String user) { username.setText(user); password.setText(""); managerStaff.setSelected(true); }

    private void doLogin() {
        String u = username.getText().trim(), p = new String(password.getPassword());
        if (u.isEmpty() || p.isEmpty()) { JOptionPane.showMessageDialog(this, "Please enter your username and password.", "Login", JOptionPane.WARNING_MESSAGE); return; }
        DataStore db = DataStore.get(); String hash = Security.hash(p);
        if (managerStaff.isSelected()) {
            if (u.equalsIgnoreCase(db.managerUsername) && hash.equals(db.managerPasswordHash)) {
                dispose(); new MainFrame("Manager").setVisible(true); return;
            }
            if (u.equalsIgnoreCase(db.staffUsername) && hash.equals(db.staffPasswordHash)) {
                dispose(); new MainFrame("Staff").setVisible(true); return;
            }
        } else {
            for (Mechanic m : db.mechanics) {
                if (m.id.equalsIgnoreCase(u) && m.passwordHash != null && hash.equals(m.passwordHash)) { dispose(); new MechanicFrame(m).setVisible(true); return; }
            }
        }
        JOptionPane.showMessageDialog(this, "Invalid username or password for the selected account type.", "Login Failed", JOptionPane.ERROR_MESSAGE);
        password.setText("");
    }
}
