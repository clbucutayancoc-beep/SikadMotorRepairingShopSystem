package sikadmotorshop.ui;

import java.awt.*;
import java.util.*;
import javax.swing.*;

/** Common window layout: dark sidebar with navigation on the left, content area on the right. */
public abstract class ShellFrame extends JFrame {
    private final String baseTitle;
    private final CardLayout cards = new CardLayout();
    private final JPanel content = new JPanel(cards);
    private final JPanel nav = new JPanel();
    private final Map<String, JButton> buttons = new LinkedHashMap<String, JButton>();
    private final Map<String, JComponent> pages = new HashMap<String, JComponent>();
    private final Map<String, String> titles = new HashMap<String, String>();

    protected ShellFrame(String baseTitle, String subtitle) {
        super(baseTitle);
        this.baseTitle = baseTitle;
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override public void windowClosing(java.awt.event.WindowEvent e) { logout(); }
        });
        setSize(1280, 760); setMinimumSize(new Dimension(1050, 620)); setLocationRelativeTo(null);

        JPanel side = new JPanel(new BorderLayout()); side.setBackground(Theme.SIDEBAR); side.setPreferredSize(new Dimension(250, 0));
        JPanel brand = new JPanel(new BorderLayout()); brand.setBackground(Theme.SIDEBAR);
        brand.setBorder(BorderFactory.createEmptyBorder(20, 18, 16, 18));
        JLabel b = new JLabel("<html><div style='width:190px'><span style='font-size:19px;color:#E65100'><b>SIKAD</b></span><br>"
                + "<span style='font-size:11px;color:#FFFFFF'><b>MOTOR REPAIRING SHOP SERVICES</b></span><br>"
                + "<span style='font-size:10px;color:#ADB5BD'>" + subtitle + "</span></div></html>");
        brand.add(b, BorderLayout.CENTER);
        JPanel line = new JPanel(); line.setBackground(Theme.ACCENT); line.setPreferredSize(new Dimension(0, 3));
        brand.add(line, BorderLayout.SOUTH);
        nav.setLayout(new BoxLayout(nav, BoxLayout.Y_AXIS)); nav.setBackground(Theme.SIDEBAR);
        nav.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        side.add(brand, BorderLayout.NORTH); side.add(nav, BorderLayout.CENTER);
        content.setBackground(Theme.BG);
        getContentPane().add(side, BorderLayout.WEST);
        getContentPane().add(content, BorderLayout.CENTER);
    }

    private JButton navButton(String label) {
        JButton b = new JButton(label);
        b.setAlignmentX(Component.LEFT_ALIGNMENT); b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        b.setHorizontalAlignment(SwingConstants.LEFT); b.setFont(new Font("Segoe UI", Font.BOLD, 14));
        b.setForeground(Color.WHITE); b.setBackground(Theme.SIDEBAR); b.setOpaque(true); b.setContentAreaFilled(true);
        b.setBorder(BorderFactory.createEmptyBorder(0, 22, 0, 10)); b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        nav.add(b);
        return b;
    }

    protected void addPage(String label, String key, String windowTitle, JComponent page) {
        JButton b = navButton(label);
        b.addActionListener(e -> showPage(key));
        buttons.put(key, b); pages.put(key, page); titles.put(key, windowTitle);
        content.add(page, key);
    }
    protected void addAction(String label, Runnable r) { navButton(label).addActionListener(e -> r.run()); }
    protected void addLogout() {
        nav.add(Box.createVerticalGlue());
        JButton b = navButton("Logout"); b.setBackground(new Color(120, 30, 30));
        b.addActionListener(e -> logout());
    }

    public void showPage(String key) {
        cards.show(content, key);
        JComponent p = pages.get(key);
        if (p instanceof Refreshable) ((Refreshable) p).refresh();
        for (Map.Entry<String, JButton> e : buttons.entrySet()) e.getValue().setBackground(e.getKey().equals(key) ? Theme.ACCENT : Theme.SIDEBAR);
        setTitle(baseTitle + " - " + titles.get(key));
    }

    protected void logout() {
        if (JOptionPane.showConfirmDialog(this, "Are you sure you want to log out?", "Confirm Logout", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            dispose();
            new LoginFrame().setVisible(true);
        }
    }
}
