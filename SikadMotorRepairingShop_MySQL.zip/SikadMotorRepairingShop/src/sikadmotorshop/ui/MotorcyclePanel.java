package sikadmotorshop.ui;

import java.time.LocalDate;
import java.util.*;
import sikadmotorshop.model.*;
import sikadmotorshop.util.*;

/** Motorcycle registration. Manager sees all; a customer (scope) sees and manages only their own. */
public class MotorcyclePanel extends CrudPanel<Motorcycle> {
    private final Customer scope;

    public MotorcyclePanel(Customer scope) { this(scope, false); }

    /** When readOnly is true, the page is for checking units only. */
    public MotorcyclePanel(Customer scope, boolean readOnly) {
        super(scope == null ? "Motorcycle Management" : "My Motorcycles");
        this.scope = scope;
        if (readOnly) { allowAdd = false; allowEdit = false; allowDelete = false; }
        buildButtons();
    }
    @Override protected String singular() { return "Motorcycle"; }
    @Override protected String[] columns() { return new String[]{"Motorcycle ID", "Customer ID", "Owner", "Brand", "Model", "Plate Number", "Engine Number", "Color", "Year", "Mileage (km)"}; }
    @Override protected int[] widths() { return new int[]{100, 90, 150, 90, 110, 100, 130, 80, 60, 100}; }
    @Override protected List<Motorcycle> items() {
        if (scope == null) return db.motorcycles;
        List<Motorcycle> l = new ArrayList<Motorcycle>();
        for (Motorcycle m : db.motorcycles) if (m.customerId.equals(scope.id)) l.add(m);
        return l;
    }
    @Override protected Object[] row(Motorcycle m) {
        return new Object[]{m.id, m.customerId, db.customerName(m.customerId), m.brand, m.model, m.plate, m.engineNo, m.color, m.year, m.mileage};
    }
    private String[] customerOptions() {
        String[] o = new String[db.customers.size()];
        for (int i = 0; i < o.length; i++) o[i] = db.customers.get(i).toString();
        return o;
    }
    @Override protected List<FieldSpec> fields(Motorcycle m) {
        if (scope == null && db.customers.isEmpty()) { warn("Register a customer first."); return null; }
        return Arrays.asList(FieldSpec.readonly("Motorcycle ID"),
                scope == null ? FieldSpec.combo("Customer", customerOptions()) : FieldSpec.readonly("Customer"),
                FieldSpec.combo("Brand", Motorcycle.BRANDS), FieldSpec.text("Model"), FieldSpec.text("Plate Number"),
                FieldSpec.text("Engine Number"), FieldSpec.text("Color"), FieldSpec.text("Year Model"), FieldSpec.text("Mileage (km)"));
    }
    @Override protected String[] valuesOf(Motorcycle m) {
        if (m == null) return new String[]{db.peekId("MOT"), scope == null ? "" : scope.toString(), "Honda", "", "", "", "", "", "0"};
        Customer c = db.customer(m.customerId);
        return new String[]{m.id, c == null ? m.customerId : c.toString(), m.brand, m.model, m.plate, m.engineNo, m.color, String.valueOf(m.year), String.valueOf(m.mileage)};
    }
    @Override protected String save(Motorcycle m, String[] v) {
        String e;
        if ((e = Validator.required("Model", v[3])) != null) return e;
        if ((e = Validator.required("Plate number", v[4])) != null) return e;
        if ((e = Validator.required("Engine number", v[5])) != null) return e;
        if ((e = Validator.required("Color", v[6])) != null) return e;
        Integer year = Validator.nonNegInt(v[7]);
        if (year == null || year < 1950 || year > LocalDate.now().getYear() + 1) return "Year model must be a valid year (1950 - " + (LocalDate.now().getYear() + 1) + ").";
        Integer mileage = Validator.nonNegInt(v[8]);
        if (mileage == null) return "Mileage must be a whole number that is not negative.";
        String plate = v[4].toUpperCase().replaceAll("\\s+", " ");
        for (Motorcycle o : db.motorcycles) if (o != m && o.plate.equalsIgnoreCase(plate)) return "Plate number " + plate + " is already registered.";
        String custId = scope != null ? scope.id : Fmt.idOf(v[1]);
        if (db.customer(custId) == null) return "Please select a valid customer.";
        if (m == null) { m = new Motorcycle(); m.id = db.nextId("MOT"); db.motorcycles.add(m); }
        m.customerId = custId; m.brand = v[2]; m.model = v[3]; m.plate = plate; m.engineNo = v[5]; m.color = v[6]; m.year = year; m.mileage = mileage;
        return null;
    }
    @Override protected String deleteError(Motorcycle m) {
        for (Appointment a : db.appointments) if (a.motorcycleId.equals(m.id)) return "This motorcycle has appointments and cannot be deleted.";
        for (RepairJob j : db.jobs) if (j.motorcycleId.equals(m.id)) return "This motorcycle has repair jobs / service history and cannot be deleted.";
        return null;
    }
    @Override protected void delete(Motorcycle m) { db.motorcycles.remove(m); }
}
