package sikadmotorshop.ui;

import sikadmotorshop.model.Mechanic;

/** Mechanic workstation: assigned walk-in repair jobs, parts used, and service history. */
public class MechanicFrame extends ShellFrame {
    public MechanicFrame(Mechanic me) {
        super("Sikad Mechanic Dashboard", "Mechanic: " + me.fullName);
        addPage("Dashboard", "dashboard", "Mechanic Dashboard", new MechanicDashboardPanel(me));
        addPage("My Repair Jobs", "jobs", "Assigned Repair Jobs", new RepairJobPanel(me));
        addPage("Spare Parts", "parts", "Spare Parts Inventory", new SparePartsPanel(false, true));
        addPage("Service History", "history", "Service History", new ServiceHistoryPanel(null));
        addLogout(); showPage("dashboard");
    }
}
