package sikadmotorshop.ui;

import java.awt.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import sikadmotorshop.data.DataStore;
import sikadmotorshop.model.*;
import sikadmotorshop.util.Fmt;

/** Manager: summary reports computed live from the data. */
public class ReportsPanel extends JPanel implements Refreshable {
    private final DataStore db = DataStore.get();
    private final DefaultTableModel revenue = make("Item", "Value");
    private final DefaultTableModel byStatus = make("Repair Status", "Number of Jobs");
    private final DefaultTableModel byService = make("Service", "Jobs Done", "Labor Revenue");
    private final DefaultTableModel byMechanic = make("Mechanic", "Active Jobs", "Finished Jobs");
    private final DefaultTableModel lowStock = make("Part ID", "Part Name", "Stock", "Reorder Level", "Stock Status");

    public ReportsPanel() {
        super(new BorderLayout(0, 12));
        setBackground(Theme.BG); setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));
        add(Theme.title("Reports"), BorderLayout.NORTH);
        JTabbedPane tabs = new JTabbedPane(); tabs.setFont(Theme.BOLD);
        tabs.addTab("Revenue Summary", tab(revenue)); tabs.addTab("Jobs by Status", tab(byStatus));
        tabs.addTab("Services Performed", tab(byService)); tabs.addTab("Mechanic Workload", tab(byMechanic));
        tabs.addTab("Low Stock Parts", tab(lowStock));
        add(tabs, BorderLayout.CENTER);
        refresh();
    }
    private static DefaultTableModel make(String... cols) {
        return new DefaultTableModel(cols, 0) { @Override public boolean isCellEditable(int r, int c) { return false; } };
    }
    private JScrollPane tab(DefaultTableModel m) {
        JTable t = new JTable(m); Theme.styleTable(t); t.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        for (int i = 0; i < m.getColumnCount(); i++) if (m.getColumnName(i).endsWith("Status")) t.getColumnModel().getColumn(i).setCellRenderer(new Theme.StatusRenderer());
        JScrollPane sp = new JScrollPane(t); sp.getViewport().setBackground(Color.WHITE); return sp;
    }
    @Override public void refresh() {
        double billed = 0, paid = 0; int nPaid = 0, nPart = 0, nUnpaid = 0;
        for (Invoice i : db.invoices) {
            RepairJob j = db.job(i.jobId); if (j == null) continue;
            billed += i.total(j); paid += i.amountPaid;
            String s = i.paymentStatus(j);
            if (s.equals("Paid")) nPaid++; else if (s.equals("Partially Paid")) nPart++; else nUnpaid++;
        }
        revenue.setRowCount(0);
        revenue.addRow(new Object[]{"Total Billed", Fmt.money(billed)});
        revenue.addRow(new Object[]{"Total Collected (Service Revenue)", Fmt.money(paid)});
        revenue.addRow(new Object[]{"Outstanding Balance", Fmt.money(billed - paid)});
        revenue.addRow(new Object[]{"Invoices Issued", db.invoices.size()});
        revenue.addRow(new Object[]{"Paid / Partially Paid / Unpaid", nPaid + " / " + nPart + " / " + nUnpaid});

        byStatus.setRowCount(0);
        for (String st : RepairJob.STATUSES) { int n = 0; for (RepairJob j : db.jobs) if (j.status.equals(st)) n++; byStatus.addRow(new Object[]{st, n}); }

        byService.setRowCount(0);
        for (Service s : db.services) {
            int n = 0; double rev = 0;
            for (RepairJob j : db.jobs) if (j.isDone() && s.id.equals(j.serviceId)) { n++; rev += j.laborCost; }
            if (n > 0) byService.addRow(new Object[]{s.name, n, Fmt.money(rev)});
        }
        byMechanic.setRowCount(0);
        for (Mechanic m : db.mechanics) {
            int a = 0, f = 0;
            for (RepairJob j : db.jobs) if (m.id.equals(j.mechanicId)) { if (j.isActive()) a++; else if (j.isDone()) f++; }
            byMechanic.addRow(new Object[]{m.fullName, a, f});
        }
        lowStock.setRowCount(0);
        for (SparePart p : db.lowStockParts()) lowStock.addRow(new Object[]{p.id, p.name, p.stock, p.reorderLevel, p.status()});
    }
}
