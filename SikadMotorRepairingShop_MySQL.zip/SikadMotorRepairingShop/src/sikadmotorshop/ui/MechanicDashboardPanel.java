package sikadmotorshop.ui;

import java.awt.*;
import javax.swing.*;
import sikadmotorshop.data.DataStore;
import sikadmotorshop.model.*;

/** Real-life mechanic workstation dashboard. */
public class MechanicDashboardPanel extends JPanel implements Refreshable {
    private final DataStore db = DataStore.get();
    private final Mechanic me;
    private final Theme.StatCard active = new Theme.StatCard("MY ACTIVE JOBS", Theme.BLUE);
    private final Theme.StatCard waiting = new Theme.StatCard("WAITING FOR PARTS", Theme.ACCENT);
    private final Theme.StatCard done = new Theme.StatCard("COMPLETED JOBS", Theme.GREEN);
    private final Theme.StatCard available = new Theme.StatCard("MY STATUS", Theme.TEXT);
    public MechanicDashboardPanel(Mechanic me) {
        this.me = me; setBackground(Theme.BG); setBorder(BorderFactory.createEmptyBorder(24,28,24,28));
        setLayout(new BorderLayout(0,18));
        JPanel head = new JPanel(new GridLayout(2,1)); head.setOpaque(false);
        JLabel t = new JLabel("Mechanic Dashboard"); t.setFont(new Font("Segoe UI",Font.BOLD,24)); t.setForeground(Theme.TEXT);
        JLabel s = new JLabel("Workstation for " + me.fullName + " - inspect, repair, update status and record parts used."); s.setForeground(Theme.MUTED);
        head.add(t); head.add(s); add(head,BorderLayout.NORTH);
        JPanel grid = new JPanel(new GridLayout(1,4,16,16)); grid.setOpaque(false);
        grid.add(active); grid.add(waiting); grid.add(done); grid.add(available); add(grid,BorderLayout.CENTER); refresh();
    }
    public void refresh() {
        db.syncMechanics(); int a=0,w=0,d=0;
        for (RepairJob j: db.jobs) if (me.id.equals(j.mechanicId)) { if(j.isDone()) d++; else if(j.status.equals("Waiting for Parts")) w++; else if(j.isActive()) a++; }
        active.set(String.valueOf(a)); waiting.set(String.valueOf(w)); done.set(String.valueOf(d)); available.set(me.status);
    }
}
