package sikadmotorshop;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import sikadmotorshop.data.DataStore;
import sikadmotorshop.ui.LoginFrame;
import sikadmotorshop.ui.Theme;

/** Application entry point for SIKAD MOTOR REPAIRING SHOP SERVICES. */
public class SikadMotorShop {
    public static void main(String[] args) {
        Theme.install();
        SwingUtilities.invokeLater(() -> {
            DataStore.get();                                   // connects to MySQL (or falls back to the local file)
            String problem = DataStore.takeStartupMessage();
            if (problem != null)
                JOptionPane.showMessageDialog(null, "Could not use the MySQL database:\n\n" + problem
                    + "\n\nThe app will use the local file sikad-data.ser instead.\nFix the problem and restart to use the database.",
                    "Database not connected", JOptionPane.WARNING_MESSAGE);
            new LoginFrame().setVisible(true);
        });
    }
}
