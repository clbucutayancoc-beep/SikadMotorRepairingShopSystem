package sikadmotorshop.model;
import java.io.Serializable;
import java.util.*;

public class Invoice implements Serializable {
    private static final long serialVersionUID = 1L;
    public String id, jobId, date;
    public double otherCharges, discount, amountPaid;
    /** TOTAL = LABOR + PARTS + OTHER CHARGES - DISCOUNT */
    public double total(RepairJob j) { return j.laborCost + j.partsCost() + otherCharges - discount; }
    /** BALANCE = TOTAL - AMOUNT PAID */
    public double balance(RepairJob j) { return total(j) - amountPaid; }
    public String paymentStatus(RepairJob j) {
        if (amountPaid <= 0.004) return "Unpaid";
        return balance(j) <= 0.004 ? "Paid" : "Partially Paid";
    }
}
