package sikadmotorshop.model;
import java.io.Serializable;
import java.util.*;

public class Appointment implements Serializable {
    private static final long serialVersionUID = 1L;
    public static final String[] TIMES = {"08:00","08:30","09:00","09:30","10:00","10:30","11:00","11:30","13:00","13:30","14:00","14:30","15:00","15:30","16:00","16:30","17:00"};
    public String id, customerId, motorcycleId, serviceId, mechanicId, date, time, concern, status = "Pending";
    public boolean isOpen() { return status.equals("Pending") || status.equals("Approved") || status.equals("Rescheduled"); }
}
