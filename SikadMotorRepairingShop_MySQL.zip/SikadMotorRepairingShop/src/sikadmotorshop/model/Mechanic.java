package sikadmotorshop.model;
import java.io.Serializable;
import java.util.*;

public class Mechanic implements Serializable {
    private static final long serialVersionUID = 1L;
    public static final String[] STATUSES = {"Available", "Busy", "On Leave", "Inactive"};
    public static final String[] SPECIALIZATIONS = {"Engine", "Electrical", "Brakes", "Tires", "General Maintenance", "Tune-Up", "Diagnostics"};
    public String id, fullName, contact, specialization, status = "Available", passwordHash;
    public int yearsExperience;
}
