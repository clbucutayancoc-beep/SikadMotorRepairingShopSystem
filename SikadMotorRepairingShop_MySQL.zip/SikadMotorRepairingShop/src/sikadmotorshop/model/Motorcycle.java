package sikadmotorshop.model;
import java.io.Serializable;
import java.util.*;

public class Motorcycle implements Serializable {
    private static final long serialVersionUID = 1L;
    public static final String[] BRANDS = {"Honda", "Yamaha", "Suzuki", "Kawasaki", "Rusi", "Motorstar", "Other"};
    public String id, customerId, brand, model, plate, engineNo, color;
    public int year, mileage;
    public String label() { return brand + " " + model + " (" + plate + ")"; }
}
