package sikadmotorshop.model;
import java.io.Serializable;
import java.util.*;

public class SparePart implements Serializable {
    private static final long serialVersionUID = 1L;
    public static final String[] CATEGORIES = {"Engine", "Brakes", "Electrical", "Tires & Tubes", "Drive Train", "Filters & Fluids", "Cables", "Other"};
    public String id, name, brand, category, supplier;
    public double unitPrice;
    public int stock, reorderLevel;
    /** Computed automatically from stock and reorder level. */
    public String status() {
        if (stock <= 0) return "Out of Stock";
        if (stock <= reorderLevel) return "Low Stock";
        return "In Stock";
    }
}
