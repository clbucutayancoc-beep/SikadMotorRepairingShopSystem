package sikadmotorshop.model;
import java.io.Serializable;
import java.util.*;

public class Service implements Serializable {
    private static final long serialVersionUID = 1L;
    public String id, name, description, duration, status = "Active";
    public double price;
}
