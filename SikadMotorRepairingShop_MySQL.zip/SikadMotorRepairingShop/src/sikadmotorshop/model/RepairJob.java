package sikadmotorshop.model;
import java.io.Serializable;
import java.util.*;

public class RepairJob implements Serializable {
    private static final long serialVersionUID = 1L;
    public static final String[] STATUSES = {"Pending", "Waiting for Inspection", "Under Inspection", "Waiting for Approval",
        "Repair in Progress", "Waiting for Parts", "Completed", "Ready for Pickup", "Released", "Cancelled"};
    public String id, appointmentId, customerId, motorcycleId, serviceId, mechanicId;
    public String dateReceived, expectedDate, complaint = "", diagnosis = "", recommended = "", status = "Pending";
    public double laborCost;
    public List<PartUsage> parts = new ArrayList<PartUsage>();
    public double partsCost() { double t = 0; for (PartUsage p : parts) t += p.total(); return t; }
    public double totalCost() { return laborCost + partsCost(); }
    public boolean isDone() { return status.equals("Completed") || status.equals("Ready for Pickup") || status.equals("Released"); }
    public boolean isActive() { return !isDone() && !status.equals("Cancelled"); }
    public String partsSummary() {
        if (parts.isEmpty()) return "-";
        StringBuilder sb = new StringBuilder();
        for (PartUsage p : parts) { if (sb.length() > 0) sb.append(", "); sb.append(p.partName).append(" x").append(p.qty); }
        return sb.toString();
    }
}
