package sikadmotorshop.model;
import java.io.Serializable;

public class Customer implements Serializable {
    private static final long serialVersionUID = 1L;
    public String id, firstName, lastName, fullName, address, contact, email, username, passwordHash;

    public String getFullName() {
        String first = firstName == null ? "" : firstName.trim();
        String last = lastName == null ? "" : lastName.trim();
        String combined = (first + " " + last).trim();
        return combined.isEmpty() ? (fullName == null ? "" : fullName.trim()) : combined;
    }

    public void syncLegacyName() {
        if ((firstName == null || firstName.trim().isEmpty()) && (lastName == null || lastName.trim().isEmpty())
                && fullName != null && !fullName.trim().isEmpty()) {
            String[] parts = fullName.trim().split("\\s+", 2);
            firstName = parts[0];
            lastName = parts.length > 1 ? parts[1] : "";
        }
        fullName = getFullName();
    }

    @Override public String toString() { return id + " - " + getFullName(); }
}
