package sikadmotorshop.model;
import java.io.Serializable;
import java.util.*;

public class PartUsage implements Serializable {
    private static final long serialVersionUID = 1L;
    public String partId, partName;
    public int qty;
    public double unitPrice;
    public double total() { return qty * unitPrice; }
}
