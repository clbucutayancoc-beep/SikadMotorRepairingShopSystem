package sikadmotorshop.data;

import java.io.*;
import java.util.*;
import sikadmotorshop.model.*;
import sikadmotorshop.util.Security;

/**
 * Central data layer. Holds all records in memory. They are stored in a MySQL database (see Database.java and
 * db.properties); if MySQL is not available the app falls back to the local file sikad-data.ser.
 * All panels talk only to this class.
 */
public class DataStore implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final File FILE = new File("sikad-data.ser");
    private static DataStore instance;
    private static String startupMessage;
    private transient Database database;

    public final List<Customer> customers = new ArrayList<Customer>();
    public final List<Motorcycle> motorcycles = new ArrayList<Motorcycle>();
    public final List<Service> services = new ArrayList<Service>();
    public final List<Mechanic> mechanics = new ArrayList<Mechanic>();
    public final List<SparePart> parts = new ArrayList<SparePart>();
    public final List<Appointment> appointments = new ArrayList<Appointment>();
    public final List<RepairJob> jobs = new ArrayList<RepairJob>();
    public final List<Invoice> invoices = new ArrayList<Invoice>();
    private final Map<String, Integer> counters = new HashMap<String, Integer>();

    /** Single manager account (kept separate from customer accounts). */
    public String managerUsername = "admin";
    public String managerPasswordHash = Security.hash("Sikad@2026!");
    /** Staff account for front-desk walk-in intake and daily shop operations. */
    public String staffUsername = "staff";
    public String staffPasswordHash = Security.hash("Staff@2026!");

    public static synchronized DataStore get() {
        if (instance == null) instance = load();
        return instance;
    }

    private static DataStore load() {
        Database.Attempt a = Database.connect();
        Database db = a.database;
        DataStore d = null;
        if (db != null) {
            try {
                if (db.hasData()) {
                    d = new DataStore();
                    db.loadInto(d);
                } else {
                    d = loadFromFile();                 // first run on this database: move any old local data in
                    if (d == null) d = freshSeeded();
                    db.saveAll(d);
                }
                d.database = db;
                d.normalize();
                return d;
            } catch (Exception e) {
                startupMessage = "Connected to MySQL, but reading/writing data failed:\n" + e.getMessage();
                d = null;
            }
        } else if (a.message != null) {
            startupMessage = a.message;
        }
        d = loadFromFile();
        if (d == null) { d = freshSeeded(); d.save(); }
        d.normalize();
        return d;
    }

    private static DataStore freshSeeded() {
        DataStore d = new DataStore();
        d.seedServices();
        d.seedParts();
        d.seedMechanics();
        return d;
    }

    private static DataStore loadFromFile() {
        if (!FILE.exists()) return null;
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(FILE))) {
            return (DataStore) in.readObject();
        } catch (Exception e) { System.err.println("Could not read data file, starting fresh: " + e); return null; }
    }

    /** Repairs old/legacy data after loading from either source. */
    private void normalize() {
        for (Customer c : customers) c.syncLegacyName();
        if (mechanics.isEmpty()) { seedMechanics(); }
        for (Mechanic m : mechanics) if (m.passwordHash == null) m.passwordHash = Security.hash("Mechanic@2026!");
        if (staffUsername == null) staffUsername = "staff";
        if (staffPasswordHash == null) staffPasswordHash = Security.hash("Staff@2026!");
    }

    /** Package-private: used by Database to read/write the ID counters. */
    Map<String, Integer> counters() { return counters; }

    /** True when data is being stored in MySQL. */
    public boolean usingDatabase() { return database != null; }

    /** Short text for the login screen. */
    public String storageDescription() {
        return database != null ? "Database: " + database.describe() + " (connected)" : "Database: not connected - using local file";
    }

    /** One-time warning about why MySQL could not be used (or null). Cleared after being read. */
    public static synchronized String takeStartupMessage() { String m = startupMessage; startupMessage = null; return m; }

    public synchronized void save() {
        if (database != null) {
            try { database.saveAll(this); return; }
            catch (Exception e) { System.err.println("Could not save to MySQL, writing local backup instead: " + e); }
        }
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(FILE))) {
            out.writeObject(this);
        } catch (IOException e) { System.err.println("Could not save data: " + e); }
    }

    private void seedServices() {
        Object[][] s = {
            {"Change Oil", "Engine oil drain and refill", 350, "30 mins"},
            {"Brake Inspection", "Inspect pads, shoes, discs and fluid", 150, "20 mins"},
            {"Brake Repair", "Brake pad/shoe replacement and adjustment", 400, "1 hour"},
            {"Tire Replacement", "Remove and replace tire", 300, "45 mins"},
            {"Tire Repair", "Puncture repair and balancing", 120, "30 mins"},
            {"Engine Tune-Up", "Spark plug, air filter and idle adjustment", 600, "2 hours"},
            {"Engine Repair", "Engine diagnosis and repair", 2500, "2-3 days"},
            {"Carburetor Cleaning", "Disassemble, clean and tune carburetor", 500, "1.5 hours"},
            {"Fuel System Inspection", "Inspect tank, lines, filter and pump", 250, "45 mins"},
            {"Battery Replacement", "Battery testing and replacement", 200, "20 mins"},
            {"Chain Adjustment", "Chain cleaning, lubrication and adjustment", 100, "20 mins"},
            {"Chain Replacement", "Chain and sprocket set replacement", 500, "1 hour"},
            {"Electrical Repair", "Wiring, lights, starter and charging system", 700, "2 hours"},
            {"Motorcycle Cleaning", "Full wash and detailing", 250, "1 hour"},
            {"General Inspection", "Complete motorcycle checkup", 300, "1 hour"},
            {"Preventive Maintenance", "Scheduled maintenance package", 800, "2 hours"},
            {"Other Repair", "Other repair (see diagnosis)", 500, "Varies"}};
        for (Object[] r : s) {
            Service sv = new Service();
            sv.id = nextId("SRV"); sv.name = (String) r[0]; sv.description = (String) r[1];
            sv.price = ((Integer) r[2]).doubleValue(); sv.duration = (String) r[3];
            services.add(sv);
        }
    }

    private void seedParts() {
        // {name, brand, category, supplier, unitPrice, stock, reorderLevel}
        Object[][] p = {
            {"Engine Oil (1L)",        "Motul",     "Filters & Fluids", "AutoParts PH",     380, 12, 5},
            {"Oil Filter",             "Yamaha OEM","Filters & Fluids", "AutoParts PH",     220, 20, 8},
            {"Air Filter",             "K&N",       "Filters & Fluids", "AutoParts PH",     180, 18, 6},
            {"Brake Fluid (DOT4)",     "Bosch",     "Filters & Fluids", "AutoParts PH",     220, 4,  5},
            {"Spark Plug",             "NGK",       "Engine",           "AutoParts PH",     250, 20, 8},
            {"Carburetor Repair Kit",  "Keihin",    "Engine",           "AutoParts PH",     450, 8,  4},
            {"Piston Ring Set",        "Honda OEM", "Engine",           "AutoParts PH",     950, 6,  3},
            {"Brake Pad Set",          "EBC",       "Brakes",           "MotoSupply Co.",   650, 15, 6},
            {"Brake Shoe",             "EBC",       "Brakes",           "MotoSupply Co.",   380, 10, 5},
            {"Chain & Sprocket Set",   "RK",        "Drive Train",      "MotoSupply Co.",   950, 8,  4},
            {"Clutch Cable",           "Honda OEM", "Cables",           "MotoSupply Co.",   180, 12, 5},
            {"Brake Cable",            "Honda OEM", "Cables",           "MotoSupply Co.",   150, 12, 5},
            {"Battery",                "Motolite",  "Electrical",       "PowerCell Inc.",  2400, 5,  3},
            {"Bulb (Headlight)",       "Philips",   "Electrical",       "PowerCell Inc.",   120, 30, 10},
            {"Fuse Set",               "Bosch",     "Electrical",       "PowerCell Inc.",    60, 0,  10},
            {"Tire (Front)",           "IRC",       "Tires & Tubes",    "MotoSupply Co.",  1850, 10, 4},
            {"Tire (Rear)",            "IRC",       "Tires & Tubes",    "MotoSupply Co.",  2100, 10, 4},
            {"Inner Tube",             "IRC",       "Tires & Tubes",    "MotoSupply Co.",   180, 15, 6}};

        for (Object[] r : p) {
            SparePart sp = new SparePart();
            sp.id = nextId("PRT");
            sp.name = (String) r[0];
            sp.brand = (String) r[1];
            sp.category = (String) r[2];
            sp.supplier = (String) r[3];
            sp.unitPrice = ((Integer) r[4]).doubleValue();
            sp.stock = (Integer) r[5];
            sp.reorderLevel = (Integer) r[6];
            parts.add(sp);
        }
    }

    private void seedMechanics() {
        Object[][] m = {
            {"Ramon Dela Cruz", "09171234567", "Engine", 8},
            {"Jun Reyes", "09181234567", "Electrical", 6},
            {"Mark Santos", "09191234567", "General Maintenance", 5}
        };
        for (Object[] r : m) {
            Mechanic me = new Mechanic(); me.id = nextId("MEC"); me.fullName=(String)r[0]; me.contact=(String)r[1]; me.specialization=(String)r[2]; me.yearsExperience=(Integer)r[3]; me.status="Available"; me.passwordHash=Security.hash("Mechanic@2026!"); mechanics.add(me);
        }
    }

    // ---- IDs ----
    public String peekId(String prefix) { return String.format("%s-%04d", prefix, counters.containsKey(prefix) ? counters.get(prefix) + 1 : 1); }
    public String nextId(String prefix) {
        int n = counters.containsKey(prefix) ? counters.get(prefix) + 1 : 1;
        counters.put(prefix, n);
        return String.format("%s-%04d", prefix, n);
    }

    // ---- finders ----
    public Customer customer(String id) { for (Customer c : customers) if (c.id.equals(id)) return c; return null; }
    public Motorcycle motorcycle(String id) { for (Motorcycle m : motorcycles) if (m.id.equals(id)) return m; return null; }
    public Service service(String id) { for (Service s : services) if (s.id.equals(id)) return s; return null; }
    public Mechanic mechanic(String id) { for (Mechanic m : mechanics) if (m.id.equals(id)) return m; return null; }
    public SparePart part(String id) { for (SparePart p : parts) if (p.id.equals(id)) return p; return null; }
    public Appointment appointment(String id) { for (Appointment a : appointments) if (a.id.equals(id)) return a; return null; }
    public RepairJob job(String id) { for (RepairJob j : jobs) if (j.id.equals(id)) return j; return null; }
    public Invoice invoiceForJob(String jobId) { for (Invoice i : invoices) if (i.jobId.equals(jobId)) return i; return null; }
    public RepairJob jobForAppointment(String apptId) {
        for (RepairJob j : jobs) if (apptId != null && apptId.equals(j.appointmentId)) return j;
        return null;
    }

    // ---- display helpers ----
    public String customerName(String id) { Customer c = customer(id); return c == null ? "-" : c.getFullName(); }
    public String motoLabel(String id) { Motorcycle m = motorcycle(id); return m == null ? "-" : m.label(); }
    public String serviceName(String id) { Service s = service(id); return s == null ? "-" : s.name; }
    public String mechanicName(String id) { Mechanic m = mechanic(id); return m == null ? "-" : m.fullName; }

    /** Auto-updates Available/Busy for mechanics based on their active repair jobs. */
    public void syncMechanics() {
        for (Mechanic m : mechanics) {
            if (!m.status.equals("Available") && !m.status.equals("Busy")) continue;
            boolean busy = false;
            for (RepairJob j : jobs)
                if (m.id.equals(j.mechanicId) && (j.status.equals("Under Inspection")
                        || j.status.equals("Repair in Progress") || j.status.equals("Waiting for Parts"))) busy = true;
            m.status = busy ? "Busy" : "Available";
        }
    }

    public List<SparePart> lowStockParts() {
        List<SparePart> l = new ArrayList<SparePart>();
        for (SparePart p : parts) if (!p.status().equals("In Stock")) l.add(p);
        return l;
    }
}
