package sikadmotorshop.data;

import java.io.*;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.*;
import sikadmotorshop.model.*;

/**
 * MySQL / MariaDB access for SIKAD (works with XAMPP + phpMyAdmin).
 * <p>
 * The screens keep working on the in-memory lists of {@link DataStore}; this class loads
 * those lists from the database at start-up and writes them back (in one transaction)
 * every time DataStore.save() is called.
 * <p>
 * Settings come from db.properties. The JDBC driver (mysql-connector-j *.jar) is found either on
 * the NetBeans classpath or in the project's lib/ folder.
 */
public final class Database {
    private static final File CONFIG = new File("db.properties");
    private static final String[] DRIVERS = {"com.mysql.cj.jdbc.Driver", "org.mariadb.jdbc.Driver", "com.mysql.jdbc.Driver"};

    private final String serverUrl, dbUrl, user, password, host, name;
    private Connection conn;

    private Database(Properties p) {
        host = p.getProperty("db.host", "localhost").trim();
        String port = p.getProperty("db.port", "3306").trim();
        name = p.getProperty("db.name", "sikad_db").trim();
        user = p.getProperty("db.user", "root").trim();
        password = p.getProperty("db.password", "");
        String opts = "?useUnicode=true&characterEncoding=UTF-8&serverTimezone=UTC&useSSL=false&allowPublicKeyRetrieval=true";
        serverUrl = "jdbc:mysql://" + host + ":" + port + "/" + opts;
        dbUrl = "jdbc:mysql://" + host + ":" + port + "/" + name + opts;
    }

    /** Result of trying to connect: either a ready Database or the reason it is not available. */
    public static final class Attempt {
        public final Database database; public final String message;
        Attempt(Database d, String m) { database = d; message = m; }
    }

    /** Reads db.properties (creating it with XAMPP defaults if missing) and connects. Never throws. */
    public static Attempt connect() {
        try {
            Properties p = new Properties();
            if (!CONFIG.exists()) writeDefaultConfig();
            try (InputStream in = new FileInputStream(CONFIG)) { p.load(in); }
            if (!"true".equalsIgnoreCase(p.getProperty("db.enabled", "true").trim()))
                return new Attempt(null, null);            // disabled on purpose: silently use the local file
            Database d = new Database(p);
            d.open();
            d.createSchema();
            return new Attempt(d, null);
        } catch (Exception e) {
            return new Attempt(null, explain(e));
        }
    }

    private static void writeDefaultConfig() throws IOException {
        try (PrintWriter w = new PrintWriter(new OutputStreamWriter(new FileOutputStream(CONFIG), StandardCharsets.UTF_8))) {
            w.println("# SIKAD database connection (XAMPP defaults: user \"root\", empty password).");
            w.println("# Start MySQL in the XAMPP Control Panel first. Set db.enabled=false to use only the local file.");
            w.println("db.enabled=true"); w.println("db.host=localhost"); w.println("db.port=3306");
            w.println("db.name=sikad_db"); w.println("db.user=root"); w.println("db.password=");
        }
    }

    public String describe() { return "MySQL database \"" + name + "\" on " + host; }

    // ---------------------------------------------------------------- connection

    private Connection raw(String url) throws SQLException {
        try { return DriverManager.getConnection(url, user, password); }
        catch (SQLException first) {
            if (!"08001".equals(first.getSQLState()) && !String.valueOf(first.getMessage()).contains("No suitable driver")) throw first;
            registerDriverFromLibFolder();                     // driver not on classpath: try lib/*.jar
            return DriverManager.getConnection(url, user, password);
        }
    }

    private void open() throws SQLException {
        try (Connection c = raw(serverUrl); Statement s = c.createStatement()) {
            s.executeUpdate("CREATE DATABASE IF NOT EXISTS `" + name + "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        }
        conn = raw(dbUrl);
    }

    private synchronized Connection conn() throws SQLException {
        if (conn == null || conn.isClosed() || !conn.isValid(2)) open();
        return conn;
    }

    /** Wraps a driver loaded from lib/ so DriverManager accepts it. */
    private static final class DriverShim implements Driver {
        private final Driver d;
        DriverShim(Driver d) { this.d = d; }
        public Connection connect(String u, Properties p) throws SQLException { return d.connect(u, p); }
        public boolean acceptsURL(String u) throws SQLException { return d.acceptsURL(u); }
        public DriverPropertyInfo[] getPropertyInfo(String u, Properties p) throws SQLException { return d.getPropertyInfo(u, p); }
        public int getMajorVersion() { return d.getMajorVersion(); }
        public int getMinorVersion() { return d.getMinorVersion(); }
        public boolean jdbcCompliant() { return d.jdbcCompliant(); }
        public java.util.logging.Logger getParentLogger() throws SQLFeatureNotSupportedException { return d.getParentLogger(); }
    }

    private static boolean driverLoaded;
    private static synchronized void registerDriverFromLibFolder() throws SQLException {
        if (driverLoaded) return;
        File[] jars = new File("lib").listFiles((dir, n) -> n.toLowerCase().endsWith(".jar"));
        if (jars == null || jars.length == 0) throw new SQLException("MySQL JDBC driver not found. Put mysql-connector-j-*.jar in the project's lib folder.");
        try {
            URL[] urls = new URL[jars.length];
            for (int i = 0; i < jars.length; i++) urls[i] = jars[i].toURI().toURL();
            URLClassLoader cl = new URLClassLoader(urls, Database.class.getClassLoader());
            for (String cn : DRIVERS) {
                try {
                    Driver d = (Driver) Class.forName(cn, true, cl).getDeclaredConstructor().newInstance();
                    DriverManager.registerDriver(new DriverShim(d));
                    driverLoaded = true; return;
                } catch (ClassNotFoundException ignore) { }
            }
        } catch (SQLException e) { throw e; }
        catch (Exception e) { throw new SQLException("Could not load the JDBC driver from lib/: " + e); }
        throw new SQLException("No MySQL/MariaDB driver class found inside the jar(s) in lib/.");
    }

    private static String explain(Exception e) {
        String m = String.valueOf(e.getMessage());
        if (m.contains("Access denied")) return "MySQL refused the user name/password in db.properties.";
        if (m.contains("Communications link failure") || m.contains("Connection refused") || m.contains("Connection reset"))
            return "MySQL is not running. Start MySQL in the XAMPP Control Panel.";
        if (m.contains("JDBC driver not found") || m.contains("No suitable driver") || m.contains("driver class found"))
            return "The MySQL JDBC driver was not found.\nPut mysql-connector-j-*.jar in the project's lib folder (or add the \"MySQL JDBC Driver\" library in NetBeans).";
        return m;
    }

    // ---------------------------------------------------------------- schema

    private void createSchema() throws SQLException, IOException {
        StringBuilder sb = new StringBuilder();
        try (InputStream in = Database.class.getResourceAsStream("schema.sql")) {
            if (in == null) throw new IOException("schema.sql is missing from the application.");
            BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            for (String line; (line = r.readLine()) != null; ) if (!line.trim().startsWith("--")) sb.append(line).append('\n');
        }
        try (Statement s = conn().createStatement()) {
            for (String sql : sb.toString().split(";")) if (!sql.trim().isEmpty()) s.executeUpdate(sql);
        }
    }

    /** True when the database already holds SIKAD data (settings are written on every save). */
    public boolean hasData() throws SQLException {
        try (Statement s = conn().createStatement(); ResultSet rs = s.executeQuery("SELECT COUNT(*) FROM app_setting")) {
            return rs.next() && rs.getInt(1) > 0;
        }
    }

    // ---------------------------------------------------------------- load

    public void loadInto(DataStore d) throws SQLException {
        Connection c = conn();
        try (Statement s = c.createStatement()) {
            try (ResultSet r = s.executeQuery("SELECT * FROM customer ORDER BY id")) {
                while (r.next()) {
                    Customer x = new Customer();
                    x.id = r.getString("id"); x.firstName = n(r.getString("first_name")); x.lastName = n(r.getString("last_name"));
                    x.address = n(r.getString("address")); x.contact = n(r.getString("contact")); x.email = n(r.getString("email"));
                    x.username = r.getString("username"); x.passwordHash = r.getString("password_hash");
                    x.syncLegacyName(); d.customers.add(x);
                }
            }
            try (ResultSet r = s.executeQuery("SELECT * FROM motorcycle ORDER BY id")) {
                while (r.next()) {
                    Motorcycle x = new Motorcycle();
                    x.id = r.getString("id"); x.customerId = r.getString("customer_id"); x.brand = n(r.getString("brand"));
                    x.model = n(r.getString("model")); x.plate = n(r.getString("plate")); x.engineNo = n(r.getString("engine_no"));
                    x.color = n(r.getString("color")); x.year = r.getInt("year_model"); x.mileage = r.getInt("mileage");
                    d.motorcycles.add(x);
                }
            }
            try (ResultSet r = s.executeQuery("SELECT * FROM service ORDER BY id")) {
                while (r.next()) {
                    Service x = new Service();
                    x.id = r.getString("id"); x.name = n(r.getString("name")); x.description = n(r.getString("description"));
                    x.duration = n(r.getString("duration")); x.status = r.getString("status") == null ? "Active" : r.getString("status");
                    x.price = r.getDouble("price"); d.services.add(x);
                }
            }
            try (ResultSet r = s.executeQuery("SELECT * FROM mechanic ORDER BY id")) {
                while (r.next()) {
                    Mechanic x = new Mechanic();
                    x.id = r.getString("id"); x.fullName = n(r.getString("full_name")); x.contact = n(r.getString("contact"));
                    x.specialization = n(r.getString("specialization")); x.status = r.getString("status") == null ? "Available" : r.getString("status");
                    x.yearsExperience = r.getInt("years_experience"); x.passwordHash = r.getString("password_hash");
                    d.mechanics.add(x);
                }
            }
            try (ResultSet r = s.executeQuery("SELECT * FROM spare_part ORDER BY id")) {
                while (r.next()) {
                    SparePart x = new SparePart();
                    x.id = r.getString("id"); x.name = n(r.getString("name")); x.brand = n(r.getString("brand"));
                    x.category = n(r.getString("category")); x.supplier = n(r.getString("supplier"));
                    x.unitPrice = r.getDouble("unit_price"); x.stock = r.getInt("stock"); x.reorderLevel = r.getInt("reorder_level");
                    d.parts.add(x);
                }
            }
            Map<String, RepairJob> byId = new HashMap<String, RepairJob>();
            try (ResultSet r = s.executeQuery("SELECT * FROM repair_job ORDER BY id")) {
                while (r.next()) {
                    RepairJob x = new RepairJob();
                    x.id = r.getString("id"); x.customerId = r.getString("customer_id"); x.motorcycleId = r.getString("motorcycle_id");
                    x.serviceId = r.getString("service_id"); x.mechanicId = r.getString("mechanic_id");
                    x.dateReceived = n(r.getString("date_received")); x.expectedDate = n(r.getString("expected_date"));
                    x.complaint = n(r.getString("complaint")); x.diagnosis = n(r.getString("diagnosis")); x.recommended = n(r.getString("recommended"));
                    x.status = r.getString("status") == null ? "Pending" : r.getString("status");
                    x.laborCost = r.getDouble("labor_cost");
                    d.jobs.add(x); byId.put(x.id, x);
                }
            }
            try (ResultSet r = s.executeQuery("SELECT * FROM part_usage ORDER BY id")) {
                while (r.next()) {
                    RepairJob j = byId.get(r.getString("repair_job_id"));
                    if (j == null) continue;
                    PartUsage u = new PartUsage();
                    u.partId = r.getString("part_id"); u.partName = n(r.getString("part_name"));
                    u.qty = r.getInt("qty"); u.unitPrice = r.getDouble("unit_price");
                    j.parts.add(u);
                }
            }
            try (ResultSet r = s.executeQuery("SELECT * FROM invoice ORDER BY id")) {
                while (r.next()) {
                    Invoice x = new Invoice();
                    x.id = r.getString("id"); x.jobId = r.getString("job_id"); x.date = n(r.getString("invoice_date"));
                    x.otherCharges = r.getDouble("other_charges"); x.discount = r.getDouble("discount"); x.amountPaid = r.getDouble("amount_paid");
                    d.invoices.add(x);
                }
            }
            try (ResultSet r = s.executeQuery("SELECT setting_key, setting_value FROM app_setting")) {
                while (r.next()) {
                    String k = r.getString(1), v = r.getString(2);
                    if (k.startsWith("counter.")) { try { d.counters().put(k.substring(8), Integer.parseInt(v)); } catch (NumberFormatException ignore) { } }
                    else if (k.equals("manager.username") && v != null) d.managerUsername = v;
                    else if (k.equals("manager.password_hash") && v != null) d.managerPasswordHash = v;
                    else if (k.equals("staff.username") && v != null) d.staffUsername = v;
                    else if (k.equals("staff.password_hash") && v != null) d.staffPasswordHash = v;
                }
            }
        }
    }

    // ---------------------------------------------------------------- save

    /** Writes everything in memory to the database in a single transaction (all or nothing). */
    public synchronized void saveAll(DataStore d) throws SQLException {
        Connection c = conn();
        boolean oldAuto = c.getAutoCommit();
        c.setAutoCommit(false);
        try (Statement s = c.createStatement()) {
            s.execute("SET FOREIGN_KEY_CHECKS=0");
            for (String t : new String[]{"part_usage", "invoice", "repair_job", "spare_part", "mechanic", "service", "motorcycle", "customer", "app_setting"})
                s.executeUpdate("DELETE FROM " + t);

            try (PreparedStatement p = c.prepareStatement("INSERT INTO customer (id,first_name,last_name,address,contact,email,username,password_hash) VALUES (?,?,?,?,?,?,?,?)")) {
                for (Customer x : d.customers) {
                    p.setString(1, x.id); p.setString(2, z(x.firstName)); p.setString(3, z(x.lastName)); p.setString(4, z(x.address));
                    p.setString(5, z(x.contact)); p.setString(6, z(x.email)); p.setString(7, x.username); p.setString(8, x.passwordHash);
                    p.addBatch();
                }
                p.executeBatch();
            }
            try (PreparedStatement p = c.prepareStatement("INSERT INTO motorcycle (id,customer_id,brand,model,plate,engine_no,color,year_model,mileage) VALUES (?,?,?,?,?,?,?,?,?)")) {
                for (Motorcycle x : d.motorcycles) {
                    p.setString(1, x.id); p.setString(2, x.customerId); p.setString(3, z(x.brand)); p.setString(4, z(x.model));
                    p.setString(5, z(x.plate)); p.setString(6, z(x.engineNo)); p.setString(7, z(x.color)); p.setInt(8, x.year); p.setInt(9, x.mileage);
                    p.addBatch();
                }
                p.executeBatch();
            }
            try (PreparedStatement p = c.prepareStatement("INSERT INTO service (id,name,description,duration,status,price) VALUES (?,?,?,?,?,?)")) {
                for (Service x : d.services) {
                    p.setString(1, x.id); p.setString(2, z(x.name)); p.setString(3, z(x.description)); p.setString(4, z(x.duration));
                    p.setString(5, x.status); p.setDouble(6, x.price); p.addBatch();
                }
                p.executeBatch();
            }
            try (PreparedStatement p = c.prepareStatement("INSERT INTO mechanic (id,full_name,contact,specialization,status,years_experience,password_hash) VALUES (?,?,?,?,?,?,?)")) {
                for (Mechanic x : d.mechanics) {
                    p.setString(1, x.id); p.setString(2, z(x.fullName)); p.setString(3, z(x.contact)); p.setString(4, z(x.specialization));
                    p.setString(5, x.status); p.setInt(6, x.yearsExperience); p.setString(7, x.passwordHash); p.addBatch();
                }
                p.executeBatch();
            }
            try (PreparedStatement p = c.prepareStatement("INSERT INTO spare_part (id,name,brand,category,supplier,unit_price,stock,reorder_level) VALUES (?,?,?,?,?,?,?,?)")) {
                for (SparePart x : d.parts) {
                    p.setString(1, x.id); p.setString(2, z(x.name)); p.setString(3, z(x.brand)); p.setString(4, z(x.category));
                    p.setString(5, z(x.supplier)); p.setDouble(6, x.unitPrice); p.setInt(7, x.stock); p.setInt(8, x.reorderLevel); p.addBatch();
                }
                p.executeBatch();
            }
            try (PreparedStatement p = c.prepareStatement("INSERT INTO repair_job (id,customer_id,motorcycle_id,service_id,mechanic_id,date_received,expected_date,complaint,diagnosis,recommended,status,labor_cost) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)")) {
                for (RepairJob x : d.jobs) {
                    p.setString(1, x.id); p.setString(2, x.customerId); p.setString(3, x.motorcycleId); p.setString(4, x.serviceId);
                    p.setString(5, x.mechanicId == null || x.mechanicId.trim().isEmpty() ? null : x.mechanicId);
                    p.setString(6, z(x.dateReceived)); p.setString(7, z(x.expectedDate)); p.setString(8, z(x.complaint));
                    p.setString(9, z(x.diagnosis)); p.setString(10, z(x.recommended)); p.setString(11, x.status); p.setDouble(12, x.laborCost);
                    p.addBatch();
                }
                p.executeBatch();
            }
            try (PreparedStatement p = c.prepareStatement("INSERT INTO part_usage (repair_job_id,part_id,part_name,qty,unit_price) VALUES (?,?,?,?,?)")) {
                for (RepairJob x : d.jobs) for (PartUsage u : x.parts) {
                    p.setString(1, x.id); p.setString(2, u.partId); p.setString(3, z(u.partName)); p.setInt(4, u.qty); p.setDouble(5, u.unitPrice);
                    p.addBatch();
                }
                p.executeBatch();
            }
            try (PreparedStatement p = c.prepareStatement("INSERT INTO invoice (id,job_id,invoice_date,other_charges,discount,amount_paid) VALUES (?,?,?,?,?,?)")) {
                for (Invoice x : d.invoices) {
                    p.setString(1, x.id); p.setString(2, x.jobId); p.setString(3, z(x.date));
                    p.setDouble(4, x.otherCharges); p.setDouble(5, x.discount); p.setDouble(6, x.amountPaid); p.addBatch();
                }
                p.executeBatch();
            }
            try (PreparedStatement p = c.prepareStatement("INSERT INTO app_setting (setting_key,setting_value) VALUES (?,?)")) {
                for (Map.Entry<String, Integer> e : d.counters().entrySet()) { p.setString(1, "counter." + e.getKey()); p.setString(2, String.valueOf(e.getValue())); p.addBatch(); }
                String[][] kv = {{"manager.username", d.managerUsername}, {"manager.password_hash", d.managerPasswordHash},
                                 {"staff.username", d.staffUsername}, {"staff.password_hash", d.staffPasswordHash},
                                 {"schema.version", "1"}};
                for (String[] e : kv) { p.setString(1, e[0]); p.setString(2, e[1]); p.addBatch(); }
                p.executeBatch();
            }
            s.execute("SET FOREIGN_KEY_CHECKS=1");
            c.commit();
        } catch (SQLException e) {
            try { c.rollback(); } catch (SQLException ignore) { }
            try (Statement s = c.createStatement()) { s.execute("SET FOREIGN_KEY_CHECKS=1"); } catch (SQLException ignore) { }
            throw e;
        } finally {
            try { c.setAutoCommit(oldAuto); } catch (SQLException ignore) { }
        }
    }

    private static String n(String s) { return s == null ? "" : s; }
    private static String z(String s) { return s == null ? "" : s; }
}
