package sikadmotorshop.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/** Formatting helpers. */
public final class Fmt {
    private Fmt() {}
    public static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    public static String money(double v) { return String.format("\u20B1%,.2f", v); }
    public static String today() { return LocalDate.now().format(DATE); }
    /** Returns the ID part of a "ID - description" combo item. */
    public static String idOf(String item) {
        if (item == null) return null;
        int i = item.indexOf(" - ");
        return i < 0 ? item.trim() : item.substring(0, i).trim();
    }
}
