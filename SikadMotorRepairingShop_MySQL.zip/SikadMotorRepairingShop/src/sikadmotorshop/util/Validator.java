package sikadmotorshop.util;

import java.time.LocalDate;
import sikadmotorshop.data.DataStore;
import sikadmotorshop.model.Customer;

/** Input validation helpers. Methods returning String return an error message or null when valid. */
public final class Validator {
    private Validator() {}

    public static String required(String label, String v) {
        return (v == null || v.trim().isEmpty()) ? label + " is required." : null;
    }
    public static boolean phone(String s) { return s != null && s.matches("^(\\+63|0)\\d{10}$"); }
    public static boolean email(String s) { return s != null && s.matches("^[\\w.+-]+@[\\w-]+(\\.[\\w-]+)+$"); }

    /** Parses a non-negative money value, or null if invalid. */
    public static Double money(String s) {
        try { double d = Double.parseDouble(s.trim().replace(",", "")); return d < 0 || Double.isNaN(d) || Double.isInfinite(d) ? null : d; }
        catch (Exception e) { return null; }
    }
    /** Parses a non-negative integer, or null if invalid. */
    public static Integer nonNegInt(String s) {
        try { int i = Integer.parseInt(s.trim()); return i < 0 ? null : i; } catch (Exception e) { return null; }
    }
    /** Parses yyyy-MM-dd strictly, or null if invalid. */
    public static LocalDate date(String s) {
        try { return LocalDate.parse(s.trim(), Fmt.DATE); } catch (Exception e) { return null; }
    }

    /** Validates customer account data (used by registration, profile and manager forms). */
    public static String customerError(String firstName, String lastName, String address, String contact, String email, String username,
                                       String pass, String confirm, boolean passwordRequired, String excludeId) {
        String e;
        if ((e = required("First name", firstName)) != null) return e;
        if ((e = required("Last name", lastName)) != null) return e;
        if ((e = required("Address", address)) != null) return e;
        if ((e = required("Contact number", contact)) != null) return e;
        if (!phone(contact.trim())) return "Contact number is invalid. Use 09XXXXXXXXX or +639XXXXXXXXX.";
        if ((e = required("Email", email)) != null) return e;
        if (!email(email.trim())) return "Email format is invalid (example: name@mail.com).";
        if ((e = required("Username", username)) != null) return e;
        String u = username.trim();
        if (u.length() < 4 || u.contains(" ")) return "Username must be at least 4 characters with no spaces.";
        DataStore db = DataStore.get();
        if (u.equalsIgnoreCase(db.managerUsername)) return "Username already exists.";
        for (Customer c : db.customers)
            if (c.username.equalsIgnoreCase(u) && !c.id.equals(excludeId)) return "Username already exists.";
        if (passwordRequired || !pass.isEmpty()) {
            if (pass.isEmpty()) return "Password cannot be empty.";
            if (pass.length() < 8) return "Password must be at least 8 characters long.";
            if (pass.length() > 64) return "Password must not exceed 64 characters.";
            if (!pass.matches(".*[A-Z].*")) return "Password must contain at least one uppercase letter.";
            if (!pass.matches(".*[a-z].*")) return "Password must contain at least one lowercase letter.";
            if (!pass.matches(".*\\d.*")) return "Password must contain at least one number.";
            if (!pass.matches(".*[^A-Za-z0-9].*")) return "Password must contain at least one special character (e.g. ! @ # $).";
            if (!pass.equals(confirm)) return "Password and confirm password do not match.";
        }
        return null;
    }
}
