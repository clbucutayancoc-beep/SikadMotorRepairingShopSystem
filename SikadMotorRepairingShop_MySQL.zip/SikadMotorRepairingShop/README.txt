SIKAD MOTOR REPAIRING SHOP SERVICES
===================================

REAL-LIFE WALK-IN WORKFLOW
--------------------------
This version models a motorcycle repair shop where customers bring motorcycles directly to the shop. There is NO online/customer booking workflow and NO customer dashboard.

Roles
-----
1. Manager / Staff - use one shared login option and the same shop dashboard for customer/unit intake, walk-in repair jobs, services, mechanics, billing, service history and reports. The account is still identified internally so inventory permissions remain enforced.
2. Manager account - can view inventory and restock/deduct stock.
3. Staff account - can view/search inventory but cannot add, edit, delete, restock or deduct stock.
4. Mechanic - uses a separate login option/dashboard, works on assigned repair jobs, records diagnosis/recommended repair, updates repair status, and records parts used.

Default logins
--------------
Manager:  admin / Sikad@2026!
Staff:   staff / Staff@2026!
Mechanic: MEC-0001 / Mechanic@2026!
          MEC-0002 / Mechanic@2026!
          MEC-0003 / Mechanic@2026!

Typical shop process
--------------------
1. Staff receives a walk-in motorcycle.
2. Staff searches for or registers the customer.
3. Staff registers the motorcycle.
4. Staff creates a Repair Job with the complaint/problem.
5. Manager or Staff assigns an available mechanic.
6. Mechanic inspects the motorcycle and records diagnosis.
7. Mechanic records parts used; inventory is deducted automatically.
8. Mechanic updates repair status until completed.
9. Staff/Manager generates the invoice and records payment.
10. Motorcycle is released after payment and the repair history is retained.

Build
-----
Java 21 / Apache NetBeans / Ant

Note
----
Appointment classes remain in the source only for backward compatibility with old serialized data. They are not part of the current UI workflow.

LATEST WORKFLOW UPDATE
- Customer intake no longer collects username/password/confirm password.
- Customer intake records the motorcycle/unit details: Brand, Model, Plate Number, Color of the Unit, and Year Model.
- Manager and Staff now share one login option and one combined dashboard.
- The Manager and Staff accounts retain separate inventory permissions: Manager can restock/deduct stock; Staff is view-only.
- Mechanics retain a separate login option and dashboard.
- There is no customer online booking workflow.


DATABASE (MySQL / XAMPP + phpMyAdmin)
-------------------------------------
Data is now stored in MySQL database "sikad_db" (tables: customer, motorcycle, service, mechanic, spare_part,
repair_job, part_usage, invoice, app_setting). Open http://localhost/phpmyadmin to see them.

Setup (one time)
1. Start Apache + MySQL in the XAMPP Control Panel.
2. Put the MySQL JDBC driver jar (mysql-connector-j-*.jar) in the project's  lib  folder.
3. Run the project. The database and tables are created automatically and filled with the sample
   services, spare parts and mechanics. The login screen shows "Database: ... (connected)" in green.
   (Optional: database/sikad_schema.sql creates the same tables by hand in phpMyAdmin.)

Settings are in  db.properties  (host, port, db.name, user, password). XAMPP default: root / empty password.
Set db.enabled=false to work only with the local file sikad-data.ser.

Notes
- If MySQL is not running or the driver is missing, the app shows a warning and uses sikad-data.ser instead.
- The first time it connects to an empty database, it imports any existing sikad-data.ser data automatically.
- Every change is written to MySQL in one transaction. Edit data in the app (not in phpMyAdmin while the app is
  open), because the app reloads from MySQL only when it starts.
